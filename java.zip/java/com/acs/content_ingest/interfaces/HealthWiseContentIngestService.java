package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.InventoryExtract;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.entities.AcsParent;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.util.List;

public interface HealthWiseContentIngestService {

    ServiceResponse<List<AcsParent>> saveAllContentTypes(String contentType, String lang) throws Exception;

    ServiceResponse<List<AcsParent>> saveHealthWiseData(String id1, String lang1) throws Exception;

    ServiceResponse<List<AcsParent>> saveAudioContent(String id, String lang);

    ServiceResponse<List<HealthWiseDto>> getAllHealthWiseArticleVideoData(String contentType, String lang);

    ServiceResponse<HealthWiseDto> getHealthWiseArticleVideoData(String docId, String language, List<InventoryExtract> inventoryExtracts) throws Exception;

    ServiceResponse<HealthWiseDto> getAudioContent(String id, String lang, JsonNode audioJsonData) throws IOException;

    ServiceResponse<List<HealthWiseDto>> getAllAudioContent(String lang1);

    List<InventoryExtract> getInventoryDataFromHealthwise(String docId, Boolean hasToMapAllData);

    List<InventoryExtract> getInventoryDataBasedOnContentType(String docId, Boolean hasToReadAllInventory, String contentType);

    String getHealthWiseArticleVideoJsonData(String accessToken, String apiUrl) throws IOException;

    String healthWiseAccessTokenGeneration() throws IOException;

    String getUName();

    String getUPwd();

    String getClientId();

    String getClientSecret();

    ServiceResponse<List<AcsParent>> saveAllAudioContent(String lang1);
}
