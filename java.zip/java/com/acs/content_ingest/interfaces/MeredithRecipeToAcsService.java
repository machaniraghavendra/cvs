package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.dto.content_fragment_dtos.AcsParentFragmentCombinedDto;
import com.acs.content_ingest.entities.AcsParent;

import java.util.List;
import java.util.Map;


public interface MeredithRecipeToAcsService {

    ServiceResponse<List<AcsParentFragmentCombinedDto>> postAllRecipeContentToAcsContentFragment(String contentType);

    ServiceResponse<AcsParentFragmentCombinedDto> postRecipeContentToAcsContentFragment(String id, String contentType, Map<String, AcsParent> mapOfLangAndAcsParent, Boolean isForUpdate);

    ServiceResponse<AcsParentFragmentCombinedDto> getRecipeContentFragment(String id, String contentType, boolean checkWhetherRecordIngested);

    ServiceResponse<List<AcsParentFragmentCombinedDto>> getAllRecipeAcsFragments(String contentType);
}
