package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.entities.AcsParent;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public interface MeredithRecipeToDbService {
    ServiceResponse<HealthWiseDto> getMeredithRecipeData(@NotNull String id, @NotNull String language, String jsonDataSpanish);
    ServiceResponse<List<HealthWiseDto>> getAllMeredithRecipes(String order, String sort_by, int page, String lang);
    ServiceResponse<List<AcsParent>> saveMeredithRecipeDataToDb(String id, String lang);
    ServiceResponse<List<AcsParent>> saveAllMeredithRecipeDataToDb(String lang);
}
