package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.entities.AcsParent;

import java.util.List;

public interface MeredithArticleToDbService {

    ServiceResponse<List<AcsParent>> saveAllMeredithArticleDataToDb(String lang);

    ServiceResponse<List<AcsParent>> saveMeredithArticleDataToDb(String id, String lang);

    ServiceResponse<List<HealthWiseDto>> getAllMeredithArticleData(String lang);

    ServiceResponse<HealthWiseDto> getMeredithArticleDataById(String id, String lang);
}
