package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.dto.content_fragment_dtos.AcsParentFragmentCombinedDto;
import com.acs.content_ingest.entities.AcsParent;

import java.util.List;
import java.util.Map;

public interface ContentToAcsService {

    ServiceResponse<List<AcsParentFragmentCombinedDto>> postAllContentToAcsContentFragments(String contentType);

    ServiceResponse<AcsParentFragmentCombinedDto> postAndUpdateContentToAcsContentFragments(String id, String contentType, Map<String, AcsParent> mapOfLangAndAcsParent, Boolean isForUpdate);

    ServiceResponse<AcsParentFragmentCombinedDto> getAcsFragments(String id, String contentType);

//    List<AcsParent> getAllContentBasedOnContentTypeFromDataBase(String language,String contentType);
//
//    AcsParentFragmentDTO getSingleContentFromDataBaseForParent(String language, String contentId, String contentType);
//
//    AcsParentFragmentDTO getSingleContentFromDataBaseForArticle(String language, String contentId, String contentType);
//
//    AcsParentFragmentDTO getSingleContentFromDataBaseForCopyRight(String language, String contentId, String contentType) throws Exception;
}
