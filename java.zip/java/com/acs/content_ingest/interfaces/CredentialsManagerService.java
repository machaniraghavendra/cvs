package com.acs.content_ingest.interfaces;

public interface CredentialsManagerService {

    String getPublicKey();
    String getPrivateKey();
    String decrypt(String value);
    String encrypt(String value);
}
