package com.acs.content_ingest.interfaces;

import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;

import java.util.List;

public interface HealthWiseDataToDb {

    ServiceResponse<List<AcsParent>> saveAllAcsParent(List<HealthWiseDto> healthWiseDtos);

    AcsParent convertHealthWiseDtoToAcsParent(HealthWiseDto healthWiseDto) throws HealthWiseException;
}
