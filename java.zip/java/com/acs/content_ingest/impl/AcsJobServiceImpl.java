package com.acs.content_ingest.impl;

import com.acs.content_ingest.entities.AcsContentIngestLogs;
import com.acs.content_ingest.entities.AcsException;
import com.acs.content_ingest.repository.AcsContentIngestLogsRepo;
import com.acs.content_ingest.repository.AcsExceptionRepo;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@Slf4j
public class AcsJobServiceImpl {

    @Autowired
    AcsContentIngestLogsRepo acsContentIngestLogsRepo;

    @Autowired
    AcsExceptionRepo acsExceptionRepo;

    @Transactional(value = Transactional.TxType.REQUIRES_NEW, rollbackOn = Exception.class)
    public AcsContentIngestLogs startTheJob(Integer acsParentId, String contentId, String contentType,
                                            String getSource) {
        return acsContentIngestLogsRepo.save(getAcsContentIngestLogs(acsParentId, contentId, contentType, getSource, false));
    }

    @Transactional(value = Transactional.TxType.REQUIRES_NEW, rollbackOn = Exception.class)
    public AcsContentIngestLogs endTheJobWithSuccess(AcsContentIngestLogs acsContentIngestLogs) {
        acsContentIngestLogs.setStatus(Boolean.TRUE);
        acsContentIngestLogsRepo.save(acsContentIngestLogs);
        return acsContentIngestLogs;
    }

    @Transactional(value = Transactional.TxType.REQUIRES_NEW, rollbackOn = Exception.class)
    public AcsContentIngestLogs endTheJobWithFail(AcsContentIngestLogs acsContentIngestLogs, String message) {
        acsContentIngestLogs.setStatus(Boolean.FALSE);
        acsContentIngestLogsRepo.save(acsContentIngestLogs);
        acsExceptionRepo.save(getAcsException(acsContentIngestLogs, message));
        LOGGER.error(message);
        return acsContentIngestLogs;
    }

    private AcsException getAcsException(AcsContentIngestLogs acsContentIngestLog, String errorMessage) {
        return AcsException.builder()
                .jobId(acsContentIngestLog.getJobId())
                .message(errorMessage)
                .createdTime(Instant.now())
                .build();
    }

    private AcsContentIngestLogs getAcsContentIngestLogs(Integer acsParentId, String contentId, String contentType,
                                                         String getSource, Boolean status) {
        return AcsContentIngestLogs.builder()
                .contentId(acsParentId)
                .sourceContentId(contentId)
                .contentType(contentType)
                .source(getSource)
                .status(status)
                .build();
    }
}
