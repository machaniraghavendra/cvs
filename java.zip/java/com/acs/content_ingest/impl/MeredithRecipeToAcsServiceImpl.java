package com.acs.content_ingest.impl;

import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.dto.content_fragment_dtos.Properties;
import com.acs.content_ingest.dto.content_fragment_dtos.*;
import com.acs.content_ingest.entities.AcsIngredientGroups;
import com.acs.content_ingest.entities.AcsIngredients;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.interfaces.MeredithRecipeToAcsService;
import com.acs.content_ingest.repository.AcsParentRepo;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.acs.content_ingest.constents.ApplicationMessage.*;
import static com.acs.content_ingest.impl.ContentToAcsServiceImpl.getValue;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toMap;

@Service
@Slf4j
public class MeredithRecipeToAcsServiceImpl implements MeredithRecipeToAcsService {

    @Autowired
    AcsParentRepo acsParentRepo;

    @Autowired
    AcsJobServiceImpl acsJobService;

    @Autowired
    ContentToAcsServiceImpl contentToAcsService;

    @Transactional
    @Override
    public ServiceResponse<AcsParentFragmentCombinedDto> postRecipeContentToAcsContentFragment(String id, String contentType, Map<String, AcsParent> mapOfLangAndAcsParent, Boolean isForUpdate) {
        try {
            var acsCombinedFragmentForRecipes = getRecipeContentFragment(id, contentType, true);
            if (!acsCombinedFragmentForRecipes.getIsSuccess()) {
                return acsCombinedFragmentForRecipes;
            }
            var combinedFragments = acsCombinedFragmentForRecipes.getResult();
            var masterFragment = combinedFragments.getMasterFragment();
            var copyRightFragment = combinedFragments.getCopyRightFragment();
            var contentFragment = combinedFragments.getContentFragment();
            var ingredientsGroupFragment = combinedFragments.getIngredientsGroupFragments();
            Map<String, AcsParent> parentRecipeByLanguage = new HashMap<>();
            if (mapOfLangAndAcsParent == null) {
                List<AcsParent> acsParentRecipes = acsParentRepo.findAllByContentIdAndContentTypeIgnoreCase(id, contentType);
                if (acsParentRecipes.isEmpty()) {
                    return new ServiceResponse<AcsParentFragmentCombinedDto>().error("No Content found for the id " + id + " for the recipe");
                }
                //Map of Lang and AcsParent
                parentRecipeByLanguage = getRecipeParentByLanguage(acsParentRecipes).get(id);
            }
            AcsParent acsParentForEn = mapOfLangAndAcsParent == null ? parentRecipeByLanguage.get(EN_US) : mapOfLangAndAcsParent.get(EN_US);
            AcsParent acsParentForEs = mapOfLangAndAcsParent == null ? parentRecipeByLanguage.get(ES_US) : mapOfLangAndAcsParent.get(ES_US);

            //Start the Job here
            var acsContentIngestLog = acsJobService.startTheJob(acsParentForEn.getId(), acsParentForEn.getContentId(),
                    acsParentForEn.getContentType(), acsParentForEn.getSource());

            try {
                var accessToken = contentToAcsService.getAccessToken();

                //Post all the Ingredient groups and ingredients
                for (var ingredientGroup : ingredientsGroupFragment) {
                    for (var ingredient : ingredientGroup.getIngredientFragments()) {
                        var ingredientUrl = String.format(PLAYGROUND_ACS_URL, "ingredients");
                        if (isForUpdate) {
                            ingredientUrl = String.format(PROD_ACS_URL_UPDATE, "ingredients", ingredient.getProperties().getName());
                        }
                        var ingredientResponse = contentToAcsService.postDataToACS(ingredient, accessToken, ingredientUrl, isForUpdate);
                        if (!ingredientResponse.getIsSuccess()) {
                            throw new HealthWiseException("Job failed while posting into Ingredient " + acsParentForEn.getContentId());
                        }
                    }
                    LOGGER.info("Completed posting the ingredients for ingredientGroup : {}", ingredientGroup.getIngredientGroupFragment().getProperties().getName());
                    var ingredientGroupUrl = String.format(PLAYGROUND_ACS_URL, "ingredients-group");
                    if (isForUpdate) {
                        ingredientGroupUrl = String.format(PROD_ACS_URL_UPDATE, "ingredients-group", ingredientGroup.getIngredientGroupFragment().getProperties().getName());
                    }
                    var ingredientGroupResponse = contentToAcsService.postDataToACS(ingredientGroup.getIngredientGroupFragment(), accessToken, ingredientGroupUrl, isForUpdate);
                    if (!ingredientGroupResponse.getIsSuccess()) {
                        throw new HealthWiseException("Job failed while posting into Ingredient group " + acsParentForEn.getContentId());
                    }
                    LOGGER.info("Completed posting the ingredientGroup : {}", ingredientGroup.getIngredientGroupFragment().getProperties().getName());
                }

                //Updating the flag of IngredientGroups And Ingredients as it completed posting to ACS
                updateFlagToTrueForIngredientGroupsAndIngredients(acsParentForEn, acsParentForEs);

                // Post CopyRight fragment
                var copyRightUrl = String.format(PLAYGROUND_ACS_URL, "copyright/recipes");
                if (isForUpdate) {
                    copyRightUrl = String.format(PROD_ACS_URL_UPDATE, "copyright/recipes", copyRightFragment.getProperties().getName());
                }
                var copyRightResponse = postToAcs(copyRightFragment, accessToken, copyRightUrl, isForUpdate);
                if (!copyRightResponse.getIsSuccess()) {
                    throw new HealthWiseException("Job failed while posting into copy right content fragment for the id : " + acsParentForEn.getContentId());
                }
                acsParentForEn.getCopyRightContentId().setStatus(true);
                if (acsParentForEs != null) acsParentForEs.getCopyRightContentId().setStatus(true);
                LOGGER.info("Completed posting the copyright for contentId : {}", acsParentForEn.getContentId());

                // Post Content fragment
                var contentUrl = String.format(PLAYGROUND_ACS_URL, "recipes");
                if (isForUpdate) {
                    contentUrl = String.format(PROD_ACS_URL_UPDATE, "recipes", contentFragment.getProperties().getName());
                }
                var contentResponse = postToAcs(contentFragment, accessToken, contentUrl, isForUpdate);
                if (!contentResponse.getIsSuccess()) {
                    throw new HealthWiseException("Job failed while posting into " + contentType + " acs fragment for content id : " + acsParentForEn.getContentId());
                }
                acsParentForEn.getRecipeContentId().setStatus(true);
                if (acsParentForEs != null) acsParentForEs.getRecipeContentId().setStatus(true);
                LOGGER.info("Completed posting the recipe content fragment for contentId : {}", acsParentForEn.getContentId());

                // Post Master fragment
                var masterUrl = String.format(PLAYGROUND_ACS_URL, "parent-content-fragments/recipes");
                if (isForUpdate) {
                    masterUrl = String.format(PROD_ACS_URL_UPDATE, "parent-content-fragments/recipes", masterFragment.getProperties().getName());
                }
                var masterResponse = postToAcs(masterFragment, accessToken, masterUrl, isForUpdate);
                if (!masterResponse.getIsSuccess()) {
                    throw new HealthWiseException("Job failed while posting into parent master fragment for content id : " + acsParentForEn.getContentId());
                }
                acsParentForEn.setStatus(true);
                if (acsParentForEs != null) acsParentForEs.setStatus(true);
                LOGGER.info("Completed posting the master fragment for contentId : {}", acsParentForEn.getContentId());

                //Update record for en and es in db and log the record as job success
                acsParentRepo.save(acsParentForEn);
                if (acsParentForEs != null) acsParentRepo.save(acsParentForEs);
                acsJobService.endTheJobWithSuccess(acsContentIngestLog);
                LOGGER.info("Job was completed successfully for content id : {}", acsParentForEn.getContentId());
                return new ServiceResponse<AcsParentFragmentCombinedDto>().success(combinedFragments);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
                acsJobService.endTheJobWithFail(acsContentIngestLog, e.getMessage());
                return new ServiceResponse<AcsParentFragmentCombinedDto>().error(e.getMessage());
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<AcsParentFragmentCombinedDto>().error(e.getMessage());
        }
    }

    private ServiceResponse<Integer> postToAcs(AcsParentFragmentDTO copyRightFragment, String accessToken, String url, Boolean isForUpdate) {
        return contentToAcsService.postDataToACS(copyRightFragment, accessToken, url, isForUpdate);
    }

    private void updateFlagToTrueForIngredientGroupsAndIngredients(AcsParent acsParentForEn, AcsParent acsParentForEs) {
        //Updating the status of Ingredients Group and Ingredients in bulk for En
        acsParentForEn.getRecipeContentId().getAcsIngredientGroups().stream().forEach(acsIngredientGroups -> {
            acsIngredientGroups.setStatus(true);
            acsIngredientGroups.getAcsIngredients().stream().forEach(acsIngredients -> {
                acsIngredients.setStatus(true);
            });
        });

        //Updating the status of Ingredients Group and Ingredients in bulk for Es
        if (acsParentForEs != null) {
            acsParentForEs.getRecipeContentId().getAcsIngredientGroups().stream().forEach(acsIngredientGroups -> {
                acsIngredientGroups.setStatus(true);
                acsIngredientGroups.getAcsIngredients().stream().forEach(acsIngredients -> {
                    acsIngredients.setStatus(true);
                });
            });
        }
    }

    @Transactional
    @Override
    public ServiceResponse<List<AcsParentFragmentCombinedDto>> postAllRecipeContentToAcsContentFragment(String contentType) {
        try {
            List<AcsParentFragmentCombinedDto> result = new ArrayList<>();
            var listOfRecipes = acsParentRepo.findAllByContentTypeIgnoreCaseAndStatus(contentType, Boolean.FALSE);
            if (listOfRecipes.isEmpty())
                return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().error("No new records to process for content : " + contentType);

            getRecipeParentByLanguage(listOfRecipes).entrySet().forEach((langAndAcsEntry) -> {
                var res = postRecipeContentToAcsContentFragment(langAndAcsEntry.getKey(), contentType, langAndAcsEntry.getValue(), Boolean.FALSE);
                if (res.getIsSuccess()) {
                    result.add(res.getResult());
                } else {
                    LOGGER.error("Failed to post recipe of id {}", langAndAcsEntry.getKey());
                }
            });

            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().success(result);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().error(e.getMessage());
        }
    }

    @Override
    public ServiceResponse<AcsParentFragmentCombinedDto> getRecipeContentFragment(@NotNull String id, String contentType, boolean checkWhetherRecordIngested) {
        try {
            //Read the data from table ACS_PARENT based on id and contentType
            List<AcsParent> acsParentRecipes = acsParentRepo.findAllByContentIdAndContentTypeIgnoreCase(id, contentType);

            if (acsParentRecipes.isEmpty()) return new ServiceResponse<AcsParentFragmentCombinedDto>()
                    .error("No Content found for the id " + id + " for the recipe");

            //Map of Lang and AcsParent
            Map<String, AcsParent> parentRecipeByLanguage = getRecipeParentByLanguage(acsParentRecipes).get(id);

            AcsParent englishRecipe = parentRecipeByLanguage.get(EN_US);
            AcsParent spanishRecipe = parentRecipeByLanguage.get(ES_US);

            if (englishRecipe == null)
                throw new ObjectNotFoundException("English recipe is not found for the id" + id, AcsParent.class);
            if (checkWhetherRecordIngested && englishRecipe.getStatus())
                return new ServiceResponse<AcsParentFragmentCombinedDto>()
                        .error("Already the content has been ingested for the " + contentType + " id : " + id);

            //Map the fragments and the move to ingredientGroups and ingredients
            AcsParentFragmentDTO masterFragment = mapAcsParentToRecipeContentFragment(englishRecipe, spanishRecipe, MASTER_FRAGMENT);
            AcsParentFragmentDTO copyRightFragment = mapAcsParentToRecipeContentFragment(englishRecipe, spanishRecipe, COPY_RIGHT_FRAGMENT);
            AcsParentFragmentDTO contentFragment = mapAcsParentToRecipeContentFragment(englishRecipe, spanishRecipe, RECIPE_FRAGMENT);

            var enIngredientGroups = englishRecipe.getRecipeContentId().getAcsIngredientGroups();

            List<AcsIngredientGroups> esIngredientGroups = new ArrayList<>();
            if (spanishRecipe != null) {
                //Creating new ArrayList to avoid UnSupportedOperationException by creating mutable
                esIngredientGroups = spanishRecipe.getRecipeContentId().getAcsIngredientGroups();
            }

            //Here declared the map of IngredientGroup and list of Ingredient as per the hierarchic
            Map<AcsParentFragmentDTO, List<AcsParentFragmentDTO>> mapOfIngredientGroupAndIngredient = new HashMap<>();

            //Here are the local variable to prepare the distinct titles for ingredients_groups and ingredients.
            var ingredientsGroupCount = 1;
            var ingredientCount = 100;

            for (var enIngredientGroup : enIngredientGroups) {
                var esIngredientGroup = new AcsIngredientGroups();
                if (!esIngredientGroups.isEmpty()) {
                    // Comparing the ordinal to get the right spanish ingredients data for english
                    esIngredientGroup = esIngredientGroups.stream().filter(es -> es.getOrdinal() == enIngredientGroup.getOrdinal())
                            .findFirst().get();
                }
                var title = englishRecipe.getTitle() + "_" + ingredientsGroupCount++;
                //Updating the mapOfIngredientGroupAndIngredient here by passing through the parameter
                ingredientCount = prepareAcsFragmentDtoWithEnAndEsIngreGroupsAndIngres(title, englishRecipe, ingredientCount, enIngredientGroup,
                        esIngredientGroup, mapOfIngredientGroupAndIngredient);
            }

            List<IngredientGroupFragments> ingredientGroupFragments = new ArrayList<>();

            //Prepare IngredientGroupFragments DTO by adding the key of Ingredient Group and List of ingredients
            // in a IngredientGroupFragments dto for to return in AcsParentFragmentCombinedDto
            mapOfIngredientGroupAndIngredient.entrySet()
                    .stream()
                    .forEach(a -> ingredientGroupFragments.add(new IngredientGroupFragments(a.getKey(), a.getValue())));

            //Mapping the references to the content and IngredientGroup fragments
            mapReferencesToContentAndIngredientsGroup(contentFragment, ingredientGroupFragments);

            //Prepare the DTO with Arguments constructor for to return
            AcsParentFragmentCombinedDto acsParentFragmentCombinedDto =
                    new AcsParentFragmentCombinedDto(masterFragment, contentFragment, copyRightFragment, ingredientGroupFragments);
            return new ServiceResponse<AcsParentFragmentCombinedDto>().success(acsParentFragmentCombinedDto);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<AcsParentFragmentCombinedDto>().error(e.getMessage());
        }
    }

    private void mapReferencesToContentAndIngredientsGroup(AcsParentFragmentDTO contentFragment, List<IngredientGroupFragments> ingredientGroupFragments) {
        //Collecting all the distinct names in groups to prepare the reference in contentFragment
        List<String> listOfIngredientGroupReferences = ingredientGroupFragments
                .stream()
                .map(a -> INGREDIENTS_GROUP_REF.concat(a.getIngredientGroupFragment().getProperties().getName())).distinct()
                .toList();
        //Setting the listOfIngredientGroupReferences to the contentFragment
        contentFragment.getProperties().getElements().setIngredientGroup(getValues(listOfIngredientGroupReferences, listOfIngredientGroupReferences));

        ingredientGroupFragments.forEach(ingredientGroup -> {
            List<String> listOfIngredientReferences = new ArrayList<>(ingredientGroup.getIngredientFragments()
                    .stream()
                    .map(a -> INGREDIENTS_REF.concat(a.getProperties().getName()))
                    .distinct()
                    .toList());
            //Setting the list of ingredient references to the respective group
            ingredientGroup.getIngredientGroupFragment().getProperties().getElements()
                    .setIngredient(getValues(listOfIngredientReferences, listOfIngredientReferences));
        });
    }

    @Override
    public ServiceResponse<List<AcsParentFragmentCombinedDto>> getAllRecipeAcsFragments(String contentType) {
        try {
            List<AcsParentFragmentCombinedDto> result = new ArrayList<>();
            var listOfRecipes = acsParentRepo.findAllByContentTypeIgnoreCaseAndStatus(contentType, Boolean.TRUE);
            listOfRecipes.stream()
                    .map(acsParent -> acsParent.getRecipeContentId().getContentId())
                    .forEach(id -> {
                        var res = getRecipeContentFragment(id, contentType, false);
                        if (res.getIsSuccess()) result.add(res.getResult());
                    });
            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().success(result);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().error(e.getMessage());
        }
    }

    /**
     * Creates the map of contentId with respect to the language and entry
     * Ex : <ContentId, Map<Lang, AcsParent>>
     *
     * @param acsParentRecipes
     * @return This method will return the map of contentId and Map of Lang and AcsParent based on the AcsParent list.
     */
    private Map<String, Map<String, AcsParent>> getRecipeParentByLanguage(List<AcsParent> acsParentRecipes) {
        return acsParentRecipes.stream()
                .collect(groupingBy(AcsParent::getContentId))
                .entrySet()
                .stream()
                .collect(Collectors.toMap(Map.Entry::getKey, a -> a.getValue()
                        .stream()
                        .collect(toMap(AcsParent::getLanguage, Function.identity()))));
    }

    /**
     * Maps the Ingredient group to AcsParentFragmentDTO from the AcsParent and enAcsIngredientGroups and esAcsIngredientGroups
     *
     * @param title
     * @param acsParent
     * @param ingredientCount
     * @param enAcsIngredientGroups
     * @param esAcsIngredientGroups
     * @param mapOfIngredientGAndIngredient
     * @return This method will return the count of Recipe to main the count in title
     */
    private int prepareAcsFragmentDtoWithEnAndEsIngreGroupsAndIngres(String title, AcsParent acsParent, Integer ingredientCount,
                                                                     @Valid @NotNull AcsIngredientGroups enAcsIngredientGroups,
                                                                     AcsIngredientGroups esAcsIngredientGroups,
                                                                     Map<AcsParentFragmentDTO, List<AcsParentFragmentDTO>> mapOfIngredientGAndIngredient) {
        AcsParentFragmentDTO acsParentFragmentDTO = new AcsParentFragmentDTO();
        Elements elements = new Elements();
        List<AcsParentFragmentDTO> ingredientsFragmentList = new ArrayList<>();

        var mapOfOrdinalOfLangAndIngredients = getMapOfOrdinalOfLangAndIngredients(enAcsIngredientGroups.getAcsIngredients(), esAcsIngredientGroups.getAcsIngredients());
        for (var ordinalMap : mapOfOrdinalOfLangAndIngredients.entrySet()) {
            var enIngredient = ordinalMap.getValue().get(EN_US);
            var esIngredient = ordinalMap.getValue().get(ES_US);
            // Mapping Ingredients and adding the values in ingredientsFragmentList.
            mapIngredients(acsParent.getTitle() + "_" + ingredientCount++, enIngredient,
                    esIngredient, acsParent, ingredientsFragmentList);
        }

        var properties = new Properties(title, String.format(CQ_MODEL, "ingredients-group"), acsParent.getTitle(),
                acsParent.getTitle(), acsParent.getTags(), null, esAcsIngredientGroups != null);
        elements.setName(getValues(enAcsIngredientGroups.getName(), esAcsIngredientGroups != null ? esAcsIngredientGroups.getName() : ""));
        properties.setElements(elements);
        acsParentFragmentDTO.setProperties(properties);
        //Update the values in map
        mapOfIngredientGAndIngredient.put(acsParentFragmentDTO, ingredientsFragmentList);
        return ingredientCount;
    }

    private Map<Integer, Map<String, AcsIngredients>> getMapOfOrdinalOfLangAndIngredients(List<AcsIngredients> enAcsIngredients, List<AcsIngredients> esAcsIngredients) {
        Map<Integer, Map<String, AcsIngredients>> result = new HashMap<>();
        var enMapOfOrdinalAndIngredients = enAcsIngredients.stream().collect(toMap(AcsIngredients::getOrdinal, Function.identity()));
        var esMapOfOrdinalAndIngredients = esAcsIngredients.stream().collect(toMap(AcsIngredients::getOrdinal, Function.identity()));

        enMapOfOrdinalAndIngredients.entrySet().forEach(ingredient -> {
            Map<String, AcsIngredients> acsIngredientsMap = new HashMap<>();
            acsIngredientsMap.put(EN_US, ingredient.getValue());
            if (!esMapOfOrdinalAndIngredients.isEmpty())
                acsIngredientsMap.put(ES_US, esMapOfOrdinalAndIngredients.get(ingredient.getKey()));
            result.put(ingredient.getKey(), acsIngredientsMap);
        });
        return result;
    }

    /**
     * Maps the AcsParentFragmentDTO and adding to the ingredientsFragmentList with the data of enAcsIngredient and esAcsIngredient objects.
     *
     * @param title
     * @param enAcsIngredient
     * @param esAcsIngredient
     * @param acsParent
     * @param ingredientsFragmentList
     */
    private void mapIngredients(String title, @Valid @NotNull AcsIngredients enAcsIngredient, AcsIngredients esAcsIngredient,
                                AcsParent acsParent, List<AcsParentFragmentDTO> ingredientsFragmentList) {
        AcsParentFragmentDTO acsParentFragmentDTO = new AcsParentFragmentDTO();
        Elements elements = new Elements();
        Properties properties = new Properties(title, String.format(CQ_MODEL, "ingredient"), acsParent.getTitle(), acsParent.getTitle(), acsParent.getTags(), null, esAcsIngredient != null);
        elements.setQuantity(getValues(enAcsIngredient.getQuantity(), esAcsIngredient != null ? (esAcsIngredient.getQuantity() == null ? BigDecimal.valueOf(0.0) : esAcsIngredient.getQuantity()) : BigDecimal.ZERO));
        elements.setUnit(getValues(enAcsIngredient.getUnit(), esAcsIngredient != null ? esAcsIngredient.getUnit() : ""));
        elements.setItem(getValues(enAcsIngredient.getItem(), esAcsIngredient != null ? esAcsIngredient.getItem() : ""));
        elements.setNote(getValues(trimNote(enAcsIngredient.getNote()), esAcsIngredient != null ? trimNote(esAcsIngredient.getNote()) : ""));
        properties.setElements(elements);
        acsParentFragmentDTO.setProperties(properties);
        //Adding the acsParentFragmentDTO in ingredientsFragmentList
        ingredientsFragmentList.add(acsParentFragmentDTO);
    }

    private static String trimNote(String note) {
        return note.replaceAll("[^a-zA-Z0-9 ]+", "").trim();
    }

//    public static void main(String[] args) {
//        System.out.println(trimNote(", hjhvhbh jkii"));
//    }

    private <T> Value<T> getValues(T englishValue, T spanishValue) {
        if (englishValue == null && spanishValue == null) {
            return null;
        }
        return getValue(englishValue, spanishValue);
    }

    /**
     * This method prepare the AcsParentFragmentDTO with required params
     *
     * @param englishRecipe
     * @param spanishRecipe
     * @param fragment
     * @return this will return the AcsParentFragmentDTO based on fragment
     */
    private AcsParentFragmentDTO mapAcsParentToRecipeContentFragment(@Valid @NotNull AcsParent englishRecipe, AcsParent spanishRecipe, String fragment) {
        AcsParentFragmentDTO acsParentFragmentDTO = new AcsParentFragmentDTO();
        Elements elements = new Elements();
        switch (fragment) {
            case COPY_RIGHT_FRAGMENT -> {
                Properties properties = new Properties(englishRecipe.getTitle(), String.format(CQ_MODEL, "copyright"), englishRecipe.getTitle(), englishRecipe.getTitle(), englishRecipe.getTags(), null, spanishRecipe != null);
                elements.setCredits(getValues(englishRecipe.getCopyRightContentId().getCredits(), spanishRecipe != null ? spanishRecipe.getCopyRightContentId().getCredits() : null));
                elements.setDisclaimer(getValues(englishRecipe.getCopyRightContentId().getDisclaimer(), spanishRecipe != null ? spanishRecipe.getCopyRightContentId().getDisclaimer() : null));
                properties.setElements(elements);
                acsParentFragmentDTO.setProperties(properties);
            }
            case RECIPE_FRAGMENT -> {
                var properties = new Properties(englishRecipe.getTitle(), String.format(CQ_MODEL, "recipe"), englishRecipe.getTitle(), englishRecipe.getTitle(), englishRecipe.getTags(), null, spanishRecipe != null);
                elements.setCaloriesPerServing(getValues(englishRecipe.getRecipeContentId().getCalories(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getCalories() : null));
                elements.setPreparationTime(getValues(englishRecipe.getRecipeContentId().getPreparationTime(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getPreparationTime() : null));
                elements.setInformation(getValues(englishRecipe.getRecipeContentId().getInformation(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getInformation() : null));
                elements.setInstructions(getValues(englishRecipe.getRecipeContentId().getInstructions(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getInstructions() : null));
                elements.setSecondsOfRead(getValues(englishRecipe.getRecipeContentId().getSecondsOfRead(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getSecondsOfRead() : null));
                elements.setImageUrl(getValues(englishRecipe.getRecipeContentId().getImage(), spanishRecipe != null ? spanishRecipe.getRecipeContentId().getImage() : null));
                elements.setCopyright(getValues(String.format(REFERENCE_COPY_RIGHT, "recipes", properties.getName()), spanishRecipe != null ? String.format(REFERENCE_COPY_RIGHT, "recipes", properties.getName()) : null));
                properties.setElements(elements);
                acsParentFragmentDTO.setProperties(properties);
            }
            case MASTER_FRAGMENT -> {
                var properties = new Properties(englishRecipe.getTitle(), String.format(CQ_MODEL, "master-content-fragment"), englishRecipe.getTitle(), englishRecipe.getTitle(), englishRecipe.getTags(), null, spanishRecipe != null);
                elements.setSourceContentID(getValues(englishRecipe.getContentId(), spanishRecipe != null ? spanishRecipe.getContentId() : null));
                elements.setContentType(getValues(englishRecipe.getContentType(), spanishRecipe != null ? spanishRecipe.getContentType() : null));
                elements.setDescription(getValues(englishRecipe.getDescription(), spanishRecipe != null ? spanishRecipe.getDescription() : null));
                elements.setTitle(getValues(englishRecipe.getTitle(), spanishRecipe != null ? spanishRecipe.getTitle() : null));
                elements.setSource(getValues(englishRecipe.getSource(), spanishRecipe != null ? spanishRecipe.getSource() : null));
                elements.setSourceVersion(getValues(englishRecipe.getSourceVersion(), spanishRecipe != null ? spanishRecipe.getSourceVersion() : null));
                elements.setCreatedTime(getValue(englishRecipe.getCreatedTime(), spanishRecipe != null ? spanishRecipe.getCreatedTime() : null));
                elements.setModifiedTime(getValues(englishRecipe.getModifiedTime(), spanishRecipe != null ? spanishRecipe.getModifiedTime() : null));
                elements.setRecipe(getValues(String.format(RECIPE_PARENT_REF, properties.getName()), spanishRecipe != null ? String.format(RECIPE_PARENT_REF, properties.getName()) : null));
                properties.setElements(elements);
                acsParentFragmentDTO.setProperties(properties);
            }
        }
        return acsParentFragmentDTO;
    }


}

