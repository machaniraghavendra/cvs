package com.acs.content_ingest.impl;

import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.IngredientGroups;
import com.acs.content_ingest.dto.Ingredients;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.entities.*;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.interfaces.HealthWiseDataToDb;
import com.acs.content_ingest.repository.AcsParentRepo;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.acs.content_ingest.constents.ApplicationMessage.*;

@Service
@Slf4j
public class HealthWiseDataToDbImpl implements HealthWiseDataToDb {

    @Autowired
    AcsParentRepo acsParentRepo;

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveAllAcsParent(List<HealthWiseDto> healthWiseDtos) {
        try {
            List<AcsParent> acsParents = new ArrayList<>();
            for (var healthWiseDto : healthWiseDtos) {
                acsParents.add(convertHealthWiseDtoToAcsParent(healthWiseDto));
            }
            acsParentRepo.saveAll(acsParents);
            return new ServiceResponse<List<AcsParent>>().success(acsParents);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public AcsParent getId(int id) {
        return acsParentRepo.findById(id).get();
    }

    @Override
    public AcsParent convertHealthWiseDtoToAcsParent(HealthWiseDto healthWiseDto) throws HealthWiseException {
        AcsParent acsParent = new AcsParent();
        try {
            BeanUtils.copyProperties(healthWiseDto, acsParent);
            acsParent.setCreatedTime(healthWiseDto.getCreatedTime());
            acsParent.setModifiedTime(healthWiseDto.getModifiedTime());
            var contentType = healthWiseDto.getContentType().toLowerCase();
            switch (contentType) {
                case ARTICLE -> mapArticleToEntity(acsParent, healthWiseDto);
                case VIDEO -> mapVideoToEntity(acsParent, healthWiseDto);
                case AUDIO -> mapAudioToEntity(acsParent, healthWiseDto);
                case RECIPE -> mapRecipeToEntity(acsParent, healthWiseDto);
            }
            mapCopyRightToEntity(acsParent, healthWiseDto);
        } catch (Exception e) {
            LOGGER.error("Error occurred while converting to entity : " + e.getMessage() + acsParent.getContentId());
            throw new HealthWiseException("Error occurred while converting to entity : " + e.getMessage());
        }
        return acsParent;
    }

    private void mapArticleToEntity(AcsParent acsParent, HealthWiseDto healthWiseDto) {
        AcsArticle acsArticle = AcsArticle.builder()
                .contentId(healthWiseDto.getContentId())
                .pageHtml(healthWiseDto.getPageHtml())
                .image(healthWiseDto.getImage())
                .secondsOfRead(healthWiseDto.getSecondsOfRead())
                .acsParent(acsParent)
                .status(Boolean.FALSE).build();
        acsParent.setArticleContentId(acsArticle);
    }

    private void mapAudioToEntity(AcsParent acsParent, HealthWiseDto healthWiseDto) {
        AcsAudio acsAudio = AcsAudio.builder().audioType(healthWiseDto.getAudioType())
                .audioUrl(healthWiseDto.getAudioUrl())
                .contentId(healthWiseDto.getContentId())
                .audioDuration(healthWiseDto.getAudioDuration())
                .transcript(healthWiseDto.getTranscript())
                .image(healthWiseDto.getImage())
                .acsParent(acsParent)
                .status(Boolean.FALSE).build();
        acsParent.setAudioContentId(acsAudio);
    }

    private void mapVideoToEntity(AcsParent acsParent, HealthWiseDto healthWiseDto) {
        AcsVideo acsVideo = AcsVideo.builder()
                .contentId(healthWiseDto.getContentId())
                .videoType(healthWiseDto.getVideoType())
                .videoDuration(healthWiseDto.getVideoDuration())
                .videoUrl(healthWiseDto.getVideoUrl())
                .closedCaptions(healthWiseDto.getClosedCaptions())
                .pageHtml(healthWiseDto.getPageHtml())
                .transcript(healthWiseDto.getTranscript())
                .image(healthWiseDto.getImage())
                .acsParent(acsParent)
                .status(Boolean.FALSE).build();
        acsParent.setVideoContentId(acsVideo);
    }

    private void mapCopyRightToEntity(AcsParent acsParent, HealthWiseDto healthWiseDto) {
        AcsCopyRight acsCopyRight = AcsCopyRight.builder()
                .content_id(healthWiseDto.getContentId())
                .credits(healthWiseDto.getCredits())
                .disclaimer(healthWiseDto.getDisclaimer())
                .acsParent(acsParent)
                .status(Boolean.FALSE).build();
        acsParent.setCopyRightContentId(acsCopyRight);
    }

    private void mapRecipeToEntity(AcsParent acsParent, HealthWiseDto healthWiseDto) {
        AcsRecipe acsRecipe = AcsRecipe.builder()
                .contentId(healthWiseDto.getContentId())
                .image(healthWiseDto.getImage())
                .status(Boolean.FALSE)
                .secondsOfRead(healthWiseDto.getSecondsOfRead())
                .preparationTime(healthWiseDto.getPreparationTime())
                .calories(healthWiseDto.getCalories())
                .information(healthWiseDto.getInformation())
                .instructions(healthWiseDto.getInstructions())
                .acsParent(acsParent).build();
        acsRecipe.setAcsIngredientGroups(getAcsIngredientGroups(healthWiseDto, acsRecipe));
        acsParent.setRecipeContentId(acsRecipe);
    }

    private List<AcsIngredientGroups> getAcsIngredientGroups(HealthWiseDto healthWiseDto, AcsRecipe acsRecipe) {
        List<AcsIngredientGroups> acsIngredientGroups = new ArrayList<>();
        for (var ingredientGroups : healthWiseDto.getIngredientGroups()) {
            var acsIngredientGroup = AcsIngredientGroups.builder()
                    .name(ingredientGroups.getName())
                    .status(Boolean.FALSE)
                    .ordinal(ingredientGroups.getOrdinal())
                    .acsIngredients(null)
                    .acsRecipe(acsRecipe).build();
            acsIngredientGroup.setAcsIngredients(getAcsIngredients(ingredientGroups.getIngredients(), acsIngredientGroup));
            acsIngredientGroups.add(acsIngredientGroup);
        }
        return acsIngredientGroups;
    }

    private List<AcsIngredients> getAcsIngredients(Ingredients[] ingredients, AcsIngredientGroups acsIngredientGroup) {
        List<AcsIngredients> acsIngredients = new ArrayList<>();
        for (var ingredient : ingredients) {
            var acsIngredient = AcsIngredients.builder()
                    .item(ingredient.getItem())
                    .note(ingredient.getNote())
                    .quantity(ingredient.getQuantity() != null ? BigDecimal.valueOf(ingredient.getQuantity().getHigh()) : null)
                    .status(Boolean.FALSE)
                    .ordinal(ingredient.getOrdinal())
                    .unit(ingredient.getUnit())
                    .build();
            acsIngredient.setAcsIngredientGroups(acsIngredientGroup);
            acsIngredients.add(acsIngredient);
        }
        return acsIngredients;
    }

}
