package com.acs.content_ingest.impl;

import com.acs.content_ingest.config.ServiceConfiguration;
import com.acs.content_ingest.dto.HealthWiseDto;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.dto.TagsAndTips;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.exceptions.JsonReadWriteException;
import com.acs.content_ingest.exceptions.ReaderException;
import com.acs.content_ingest.interfaces.CredentialsManagerService;
import com.acs.content_ingest.interfaces.HealthWiseDataToDb;
import com.acs.content_ingest.interfaces.MeredithArticleToDbService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import static com.acs.content_ingest.constents.ApplicationMessage.EN_US;
import static com.acs.content_ingest.constents.ApplicationMessage.ES_US;
import static org.apache.commons.io.IOUtils.resourceToString;

@Service
@Slf4j
public class MeredithArticleToDbServiceImpl implements MeredithArticleToDbService {

    @Autowired
    private ServiceConfiguration serviceConfiguration;

    @Autowired
    private CredentialsManagerService credentialsManager;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private HealthWiseContentIngestServiceImpl healthWiseContentIngestService;

    @Autowired
    private HealthWiseDataToDb healthWiseDataToDb;

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveAllMeredithArticleDataToDb(String lang) {
        try {
            var result = getAllMeredithArticleData(lang);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(result.getResult());
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveMeredithArticleDataToDb(String id, String lang) {
        try {
            if (healthWiseContentIngestService.isRecordAlreadyPresent(id, lang)) {
                return new ServiceResponse<List<AcsParent>>().error("Record already present in DB docId :" + id + "and lang : " + lang, HttpStatus.BAD_REQUEST);
            }
            var result = getMeredithArticleDataById(id, lang);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(List.of(result.getResult()));
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ServiceResponse<List<HealthWiseDto>> getAllMeredithArticleData(String lang) {
        var listOfMeredithDtos = new ArrayList<HealthWiseDto>();
        try {
            var listOfMeredithIds = getMeredithArticleDetailIds("DSC", "id", 0, lang);
            if (listOfMeredithIds.getIsSuccess()) {
                for (var id : listOfMeredithIds.getResult()) {
                    var result = getMeredithArticleDataById(id, lang);
                    if (result.getIsSuccess()) {
                        listOfMeredithDtos.add(result.getResult());
                    } else {
                        LOGGER.error("Error while getting details for id : {}, so moving for next id", id);
                    }
                }
            }
            return new ServiceResponse<List<HealthWiseDto>>().success(listOfMeredithDtos);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return new ServiceResponse<List<HealthWiseDto>>().error("Something went wrong while getting details");
    }

    @Override
    public ServiceResponse<HealthWiseDto> getMeredithArticleDataById(String id, String lang) {
        try {
            var result = getMeredithArticleData(id, lang);
            if (result.getIsSuccess()) {
                return new ServiceResponse<HealthWiseDto>().success(result.getResult());
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return new ServiceResponse<HealthWiseDto>().error("Something went wrong while getting details for the id : " + id);
    }

    private ServiceResponse<List<String>> getMeredithArticleDetailIds(String order, String sort_by, int page, String lang) throws Exception {
        var response = getMeredithArticleDetailJsonNodes(order, sort_by, page, lang);
        if (response.getIsSuccess()) {
            List<String> ids = new ArrayList<>();
            var result = response.getResult();
            IntStream.of(0, result.size()).forEach(i -> ids.add(result.get(i).get("id").asText()));
            return new ServiceResponse<List<String>>().success(ids);
        }
        return new ServiceResponse<List<String>>().error(response.getErrorMessage());
    }

    public ServiceResponse<List<JsonNode>> getMeredithArticleDetailJsonNodes(String order, String sort_by, int page, String lang) throws Exception {
        var listOfMeredithIds = new ArrayList<JsonNode>();
        boolean terminate = true;
        do {
            String jsonData;
            if (lang.equalsIgnoreCase(EN_US))
                jsonData = getMeredithArticleJsonData(null, order, sort_by, page);
            else
                jsonData = getDataFromFile(serviceConfiguration.spanishMeredithContent);
            try {
                var rootNode = objectMapper.readTree(jsonData);
                for (int i = 0; i < rootNode.get("result").size(); i++) {
                    listOfMeredithIds.add(rootNode.get("result").get(i));
                    if (terminate && i == rootNode.get("result").size() - 1) {
                        terminate = false;
                    }
                }
                page++;
            } catch (JsonProcessingException e) {
                LOGGER.error(e.getMessage(), e);
                return new ServiceResponse<List<JsonNode>>().error(e.getMessage());
            }
        } while (terminate);
        return new ServiceResponse<List<JsonNode>>().success(listOfMeredithIds);
    }

    private ServiceResponse<HealthWiseDto> getMeredithArticleData(@NotNull String id, @NotNull String language) {
        var healthWiseDto = new HealthWiseDto();
        if (!(language.equalsIgnoreCase(EN_US) || language.equalsIgnoreCase(ES_US))) {
            return new ServiceResponse<HealthWiseDto>().error("Language Parameter Must be en-us or es-us", HttpStatus.BAD_REQUEST);
        }
        try {
            String meredithJsonData;
            if (language.equalsIgnoreCase(EN_US)) {
                meredithJsonData = getMeredithArticleJsonData(id, null, null, null);
            } else {
                meredithJsonData = getDataFromFile(serviceConfiguration.spanishMeredithContent);
            }
            if (meredithJsonData != null) {
                var rootNode = objectMapper.readTree(meredithJsonData);
                var rootNodeData = rootNode.get("result");
                if (language.equalsIgnoreCase(ES_US)) {
                    rootNodeData = getSpanishDataJsonDataForId(id, rootNodeData);
                }
                healthWiseDto.setContentId(Objects.requireNonNull(rootNodeData.get("id")).asText());
                healthWiseDto.setContentType(Objects.requireNonNull(rootNodeData.get("contentType").asText()));
                healthWiseDto.setTitle(Objects.requireNonNull(rootNodeData.get("title")).asText());
                healthWiseDto.setDescription(Objects.requireNonNull(rootNodeData.get("subtitle")).asText());
                healthWiseDto.setLanguage(language);
                healthWiseDto.setSource("Meredith");
                healthWiseDto.setSourceVersion(BigDecimal.valueOf(1.1));
                var createdAt = rootNodeData.get("createdAt").asText();
                var updatedAt = rootNodeData.get("updatedAt").asText();
                healthWiseDto.setCreatedTime(createdAt.substring(0, createdAt.indexOf("T")));
                healthWiseDto.setModifiedTime(updatedAt.substring(0, updatedAt.indexOf("T")));
                healthWiseDto.setTags(getTagsForMeredith(healthWiseDto));
                healthWiseDto.setPageHtml(rootNodeData.get("textWithHtml").asText());
                healthWiseDto.setCredits("Dotdash Meredith");
                healthWiseDto.setDisclaimer("<div><p> </p></div>");
                healthWiseDto.setSecondsOfRead(healthWiseContentIngestService.getEstimatedReadTime(healthWiseDto.getPageHtml()) * 60);
                return new ServiceResponse<HealthWiseDto>().success(healthWiseContentIngestService.sanitizeHealthWiseData(healthWiseDto));
            } else {
                throw new IOException("There is no data available from the HealthWise API for the id : " + id);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage() + id);
            return new ServiceResponse<HealthWiseDto>().error(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private List<String> getTagsForMeredith(HealthWiseDto meredithArticleData) throws JsonProcessingException {
        var tipsDataFromFile = getDataFromFile(serviceConfiguration.tagsTips);
        var tagsNode = objectMapper.readTree(tipsDataFromFile);
        var tipsAndTags = objectMapper.treeToValue(tagsNode, TagsAndTips.class);
        var tipsAndStrategy = tipsAndTags.getTipsAndStrategies().stream()
                .filter(tips -> tips.getId().equalsIgnoreCase(meredithArticleData.getContentId())).toList();
        var tags = new ArrayList<String>();
        if (!tipsAndStrategy.isEmpty()) {
            var category = tipsAndStrategy.get(0).getTag();
            tags.add("ahm:MAH Tags/Topic/Tips and Strategies/" + category);
            if (!tags.isEmpty()) {
                tags.addAll(List.of(
                        "ahm:MAH Tags/Gender/Male",
                        "ahm:MAH Tags/Gender/Female",
                        "ahm:MAH Tags/Age/Childhood",
                        "ahm:MAH Tags/Age/Teen",
                        "ahm:MAH Tags/Age/Adult",
                        "ahm:MAH Tags/Age/Senior"
                ));
            }
            meredithArticleData.setImage(healthWiseContentIngestService.getImageUrlWithCategory(category));
        }
        return tags;
    }


    private String getMeredithArticleJsonData(String id, String order, String sort_by, Integer page) throws IOException {
        URL url = null;
        try {
            if (id == null) {
                url = new URL(serviceConfiguration.meredithArticleUrl + "?sort_by=" + sort_by + "&order=" + order +
                        "&page=" + page + "&per_page=100");
            } else {
                url = new URL(serviceConfiguration.meredithArticleUrl + id);
            }
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            LOGGER.info("Connection object: " + connection.getURL());
            connection.setRequestMethod("GET");
            connection.setRequestProperty("X-API-KEY", credentialsManager.decrypt(serviceConfiguration.apiKey));
            connection.setRequestProperty("X-HW-Version", "2");
            connection.setRequestProperty("Accept", "application/json");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                LOGGER.info("Trying to get the content by Sending request, without the proxy server, to the meredith ");
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    LOGGER.info("Content received from the meredith without the proxy server");
                    String inputLine;
                    StringBuilder response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    return response.toString();
                }
            } else {
                LOGGER.info("Request failed with response code (without proxy server): " + responseCode);
            }
            LOGGER.info("Failed to execute connection.getResponseCode(), Response Code:  (without proxy server): " + responseCode);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
            String proxyHost = serviceConfiguration.proxyHost;
            int proxyPort = serviceConfiguration.proxyPort;
            String proxyUser = getUName();
            String proxyPassword = getUPwd();
            Authenticator.setDefault(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
                }
            });
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
            if (url == null) {
                if (!(StringUtils.isEmpty(order) && StringUtils.isEmpty(sort_by))) {
                    url = new URL(serviceConfiguration.meredithArticleUrl + "?sort_by=" + sort_by + "&order=" + order +
                            "&page=" + page + "&per_page=100");
                } else {
                    url = new URL(serviceConfiguration.meredithArticleUrl + id);
                }
            }
            HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);
            connection.setRequestProperty("X-API-KEY", credentialsManager.decrypt(serviceConfiguration.apiKey));
            //credentialsManager.decrypt(recipeServiceConfig.apiKey)
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            LOGGER.info("Content received from the meredith via the aetna proxy server , executed the connection.getInputStream() successfully");
            String line;
            StringBuilder response = new StringBuilder();
            while (true) {
                try {
                    if ((line = reader.readLine()) == null) break;
                } catch (IOException e) {
                    throw new JsonReadWriteException(e);
                }
                response.append(line);
            }
            try {
                reader.close();
            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
                throw new ReaderException(e);
            }
            connection.disconnect(); // check if closed successfully or not
            LOGGER.info("Content received from the meredith via the aetna proxy server");
            return response.toString();
        }
        return null;
    }

    public String getUName() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserName);
    }

    public String getUPwd() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserPassword);
    }

    protected String getDataFromFile(String url) {
        String data = null;
        if (url.isEmpty()) return "";
        try {
            data = resourceToString(url, Charset.defaultCharset(), this.getClass().getClassLoader());
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
        return StringUtils.hasLength(data) ? data : null;
    }

    protected JsonNode getSpanishDataJsonDataForId(String id, JsonNode jsonNode) {
        for (int i = 0; i <= jsonNode.size(); i++) {
            if (id.equalsIgnoreCase(jsonNode.get(i).get("id").asText())) {
                return jsonNode.get(i);
            }
        }
        return null;
    }

}
