package com.acs.content_ingest.impl;

import com.acs.content_ingest.config.ServiceConfiguration;
import com.acs.content_ingest.interfaces.CredentialsManagerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import static com.acs.content_ingest.constents.ApplicationMessage.RSA;

@Component
@Slf4j
public class CredentialsManagerServiceImpl implements CredentialsManagerService {
    @Autowired
    private ServiceConfiguration serviceConfiguration;

    @Override
    public String getPublicKey() {
        return serviceConfiguration.proxyPublicKey;
    }

    @Override
    public String getPrivateKey() {
        return serviceConfiguration.proxyPrivateKey;
    }

    @Override
    public String decrypt(String encryptedValue) {
        // Decryption using private key
        Cipher decryptCipher = null;
        try {
            decryptCipher = Cipher.getInstance(RSA);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        }
        try {
            var privateKeyBytes = Base64.getDecoder().decode(getPrivateKey());
            var privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
            var kf = KeyFactory.getInstance(RSA);
            PrivateKey privateKey = kf.generatePrivate(privateKeySpec);
            try {
                decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);
            }catch (NullPointerException e){
                e.printStackTrace();
            }
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        try {
            byte[] decryptedValueBytes = null;
            try {
                decryptedValueBytes = decryptCipher.doFinal(Base64.getDecoder().decode(encryptedValue));
            }catch (NullPointerException e){
                e.printStackTrace();
            }
            String decryptedValue = new String(decryptedValueBytes);
            return decryptedValue;
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String encrypt(String value) {
        try {
            // Encryption using public key
            Cipher encryptCipher = Cipher.getInstance(RSA);
            var publicKeyBytes = Base64.getDecoder().decode(getPublicKey());
            var publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
            var kf = KeyFactory.getInstance(RSA);
            PublicKey publicKey = kf.generatePublic(publicKeySpec);

            encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encryptedValueBytes = encryptCipher.doFinal(value.getBytes());
            String encryptedValue = Base64.getEncoder().encodeToString(encryptedValueBytes);
            return encryptedValue;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return null;
    }
}
