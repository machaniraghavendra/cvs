package com.acs.content_ingest.impl;

import com.acs.content_ingest.config.ServiceConfiguration;
import com.acs.content_ingest.dto.ServiceResponse;
import com.acs.content_ingest.dto.content_fragment_dtos.Properties;
import com.acs.content_ingest.dto.content_fragment_dtos.*;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.interfaces.ContentToAcsService;
import com.acs.content_ingest.interfaces.CredentialsManagerService;
import com.acs.content_ingest.repository.AcsParentRepo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.entity.UrlEncodedFormEntity;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.http.message.BasicNameValuePair;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.acs.content_ingest.constents.ApplicationMessage.*;

@Service
@Slf4j
public class ContentToAcsServiceImpl implements ContentToAcsService {

    @Autowired
    AcsParentRepo acsParentRepo;

    @Autowired
    ServiceConfiguration serviceConfiguration;

    @Autowired
    CredentialsManagerService credentialsManagerService;

    @Autowired
    AcsJobServiceImpl acsJobService;

    @Override
    @Transactional
    public ServiceResponse<List<AcsParentFragmentCombinedDto>> postAllContentToAcsContentFragments(String contentType) {
        try {
            var acsParents = acsParentRepo.findAllByContentTypeIgnoreCaseAndStatus(contentType, Boolean.FALSE);
            var mapOfAcsParentWithIdAndLang = getMapOfAcsParentWithAcsList(acsParents);
            List<AcsParentFragmentCombinedDto> responseList = new ArrayList<>();
            for (var mapOfAcsEntry : mapOfAcsParentWithIdAndLang.entrySet()) {
                var result = postAndUpdateContentToAcsContentFragments(mapOfAcsEntry.getKey(), contentType, mapOfAcsEntry.getValue(), Boolean.FALSE);
                if (!result.getIsSuccess()) {
                    LOGGER.error(result.getErrorMessage());
                }
                responseList.add(result.getResult());
            }
            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().success(responseList);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<List<AcsParentFragmentCombinedDto>>().error(e.getMessage());
        }
    }

    @Transactional
    @Override
    public ServiceResponse<AcsParentFragmentCombinedDto> postAndUpdateContentToAcsContentFragments(String id, String contentType, Map<String, AcsParent> mapOfLangAndAcsParent, Boolean isForUpdate) {
        try {
            if (mapOfLangAndAcsParent == null) {
                var acsParentsById = acsParentRepo.findAllByContentIdAndContentTypeIgnoreCase(id, contentType);
                mapOfLangAndAcsParent = getMapOfAcsParentWithAcsList(acsParentsById).getOrDefault(id, null);
            }
            var acsParentForEn = mapOfLangAndAcsParent.getOrDefault(EN_US, null);
            var acsParentForEs = mapOfLangAndAcsParent.getOrDefault(ES_US, null);

            if (acsParentForEn == null) {
                return new ServiceResponse<AcsParentFragmentCombinedDto>().error("EN_US data not found for the id : " + id);
            }
            if (!acsParentForEn.getStatus()) {
                var acsFragmentDtoForMaster = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, MASTER_FRAGMENT);
                var acsFragmentDtoForCopyRight = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, COPY_RIGHT_FRAGMENT);
                var acsFragmentDtoForContentType = new AcsParentFragmentDTO();
                if (ARTICLE.equalsIgnoreCase(contentType)) {
                    acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, ARTICLE_FRAGMENT);
                } else if (VIDEO.equalsIgnoreCase(contentType)) {
                    acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, VIDEO_FRAGMENT);
                } else if (AUDIO.equalsIgnoreCase(contentType)) {
                    acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, AUDIO_FRAGMENT);
                }
                var acsJobLog = acsJobService.startTheJob(acsParentForEn.getId(), acsParentForEn.getContentId(),
                        acsParentForEn.getContentType(), acsParentForEn.getSource());
                try {
                    var accessToken = getAccessToken();
                    var copyRightUrl = !isForUpdate ? String.format(PROD_ACS_URL, "copyright/" + contentType.toLowerCase() + "s") : String.format(PROD_ACS_URL_UPDATE, ("copyright/" + contentType.toLowerCase() + "s"), acsFragmentDtoForCopyRight.getProperties().getName());
                    var copyRightResponse = postDataToACS(acsFragmentDtoForCopyRight, accessToken, copyRightUrl, isForUpdate);
                    if (copyRightResponse.getIsSuccess()) {
                        acsParentForEn.getCopyRightContentId().setStatus(Boolean.TRUE);
                        if (acsParentForEs != null) acsParentForEs.getCopyRightContentId().setStatus(Boolean.TRUE);
                        var contentTypeResponse = new ServiceResponse<Integer>();
                        if (ARTICLE.equalsIgnoreCase(contentType)) {
                            var articleUrl = !isForUpdate ? String.format(PROD_ACS_URL, "articles") : String.format(PROD_ACS_URL_UPDATE, "articles", acsFragmentDtoForContentType.getProperties().getName());
                            contentTypeResponse = postDataToACS(acsFragmentDtoForContentType, accessToken, articleUrl, isForUpdate);
                        } else if (VIDEO.equalsIgnoreCase(contentType)) {
                            var videoUrl = !isForUpdate ? String.format(PROD_ACS_URL, "videos") : String.format(PROD_ACS_URL_UPDATE, "videos", acsFragmentDtoForContentType.getProperties().getName());
                            contentTypeResponse = postDataToACS(acsFragmentDtoForContentType, accessToken, videoUrl, isForUpdate);
                        } else if (AUDIO.equalsIgnoreCase(contentType)) {
                            var audioUrl = !isForUpdate ? String.format(PROD_ACS_URL, "audios") : String.format(PROD_ACS_URL_UPDATE, "audios", acsFragmentDtoForContentType.getProperties().getName());
                            contentTypeResponse = postDataToACS(acsFragmentDtoForContentType, accessToken, audioUrl, isForUpdate);
                        }
                        if (contentTypeResponse.getIsSuccess()) {
                            if (ARTICLE.equalsIgnoreCase(contentType)) {
                                acsParentForEn.getArticleContentId().setStatus(Boolean.TRUE);
                                if (acsParentForEs != null)
                                    acsParentForEs.getArticleContentId().setStatus(Boolean.TRUE);
                            } else if (VIDEO.equalsIgnoreCase(contentType)) {
                                acsParentForEn.getVideoContentId().setStatus(Boolean.TRUE);
                                if (acsParentForEs != null) acsParentForEs.getVideoContentId().setStatus(Boolean.TRUE);
                            } else if (AUDIO.equalsIgnoreCase(contentType)) {
                                acsParentForEn.getAudioContentId().setStatus(Boolean.TRUE);
                                if (acsParentForEs != null) acsParentForEs.getAudioContentId().setStatus(Boolean.TRUE);
                            }

                            String url= String.format(PROD_ACS_URL, "parent-content-fragments/" + contentType.toLowerCase() + "s");
                            if("meredith".equalsIgnoreCase( acsFragmentDtoForMaster.getProperties().getElements().getSource().getValue())){
                                url= String.format(PROD_ACS_URL, "parent-content-fragments/tips---strategies");
                            }
                            var masterResponse = postDataToACS(acsFragmentDtoForMaster, accessToken, url, isForUpdate);
                            if (masterResponse.getIsSuccess()) {
                                acsParentForEn.setStatus(Boolean.TRUE);
                                if (acsParentForEs != null) acsParentForEs.setStatus(Boolean.TRUE);
                                acsParentRepo.save(acsParentForEn);
                                if (acsParentForEs != null) acsParentRepo.save(acsParentForEs);
                                acsJobService.endTheJobWithSuccess(acsJobLog);
                                LOGGER.info("Job was completed successfully for content id : {}", acsParentForEn.getContentId());
                                return new ServiceResponse<AcsParentFragmentCombinedDto>().success(new AcsParentFragmentCombinedDto(acsFragmentDtoForMaster, acsFragmentDtoForContentType, acsFragmentDtoForCopyRight, null));
                            } else {
                                acsJobService.endTheJobWithFail(acsJobLog, "Job failed while posting into parent content fragment for content id : " + acsParentForEn.getContentId());
                            }
                        } else {
                            acsJobService.endTheJobWithFail(acsJobLog, "Job failed while posting into " + contentType + " acs fragment for content id : " + acsParentForEn.getContentId());
                        }
                    } else {
                        acsJobService.endTheJobWithFail(acsJobLog, "Job failed while posting into copy right content fragment for the id : " + acsParentForEn.getContentId());
                    }
                } catch (Exception e) {
                    LOGGER.error("Something went wrong after job started for the content id : " + acsParentForEn.getContentId() + e.getMessage(), e);
                    acsJobService.endTheJobWithFail(acsJobLog, "Something went wrong after job started for the content id : " + acsParentForEn.getContentId());
                }
            } else {
                throw new HealthWiseException("Already the content has been ingested for the " + contentType + " id : " + id);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<AcsParentFragmentCombinedDto>().error("Something went wrong before job started while posting id " + id + ": " + e.getMessage());
        }
        return new ServiceResponse<AcsParentFragmentCombinedDto>().error("Something went wrong before job started while posting id " + id);
    }

    @Transactional
    @Override
    public ServiceResponse<AcsParentFragmentCombinedDto> getAcsFragments(String id, String contentType) {
        try {
            List<AcsParent> acsParents;
            if (id != null) {
                acsParents = acsParentRepo.findAllByContentIdAndContentTypeIgnoreCase(id, contentType);
            } else {
                acsParents = acsParentRepo.findAllByContentTypeIgnoreCaseAndStatus(contentType, Boolean.FALSE);
            }
            var mapOfAcsParentWithId = getMapOfAcsParentWithAcsList(acsParents);
            var acsParentMap = mapOfAcsParentWithId.get(id);

            var acsParentForEn = acsParentMap.getOrDefault(EN_US, null);
            var acsParentForEs = acsParentMap.getOrDefault(ES_US, null);

            if (acsParentForEn == null) {
                return new ServiceResponse<AcsParentFragmentCombinedDto>().error("EN_US data not found for the id : " + id);
            }
            var acsFragmentDtoForMaster = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, MASTER_FRAGMENT);
            var acsFragmentDtoForCopyRight = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, COPY_RIGHT_FRAGMENT);
            var acsFragmentDtoForContentType = new AcsParentFragmentDTO();
            if (ARTICLE.equalsIgnoreCase(contentType)) {
                acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, ARTICLE_FRAGMENT);
            } else if (VIDEO.equalsIgnoreCase(contentType)) {
                acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, VIDEO_FRAGMENT);
            } else if (AUDIO.equalsIgnoreCase(contentType)) {
                acsFragmentDtoForContentType = mapAcsParentToAcsParentFragmentDtoByContentType(acsParentForEn, acsParentForEs, AUDIO_FRAGMENT);
            }
            return new ServiceResponse<AcsParentFragmentCombinedDto>().success(new AcsParentFragmentCombinedDto(acsFragmentDtoForMaster, acsFragmentDtoForContentType, acsFragmentDtoForCopyRight, null));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return new ServiceResponse<AcsParentFragmentCombinedDto>().error("Something went wrong");
    }

    private Map<String, Map<String, AcsParent>> getMapOfAcsParentWithAcsList(@Valid @NotNull List<AcsParent> acsParents) {
        Map<String, Map<String, AcsParent>> mapOfAcsParentWithAcsList = new HashMap<>();
        Map<String, List<AcsParent>> acsParentsWithId = acsParents.stream().collect(Collectors.groupingBy(AcsParent::getContentId));
        for (var acsParentsEntry : acsParentsWithId.entrySet()) {
            Map<String, AcsParent> acsParentMap = acsParentsEntry.getValue().stream().collect(Collectors.toMap(AcsParent::getLanguage, Function.identity()));
            mapOfAcsParentWithAcsList.put(acsParentsEntry.getKey(), acsParentMap);
        }
        return mapOfAcsParentWithAcsList;
    }

    private AcsParentFragmentDTO mapAcsParentToAcsParentFragmentDtoByContentType(@NotNull AcsParent enAcsParent, AcsParent esAcsParent, String fragment) {
        try {
            var acsParentFragmentDTO = new AcsParentFragmentDTO();
            var elements = new Elements();
            switch (fragment) {
                case COPY_RIGHT_FRAGMENT -> {
                    var properties = new Properties(enAcsParent.getTitle(), String.format(CQ_MODEL, "copyright"), enAcsParent.getTitle(), enAcsParent.getTitle(), enAcsParent.getTags(), null, esAcsParent != null);
                    elements.setCredits(getValue(enAcsParent.getCopyRightContentId().getCredits(), esAcsParent != null ? esAcsParent.getCopyRightContentId().getCredits() : null));
                    elements.setDisclaimer(getValue(enAcsParent.getCopyRightContentId().getDisclaimer(), esAcsParent != null ? esAcsParent.getCopyRightContentId().getDisclaimer() : null));
                    properties.setElements(elements);
                    acsParentFragmentDTO.setProperties(properties);
                }
                case ARTICLE_FRAGMENT -> {
                    var properties = new Properties(enAcsParent.getTitle(), String.format(CQ_MODEL, "article"), enAcsParent.getTitle(), enAcsParent.getTitle(), enAcsParent.getTags(), null, esAcsParent != null);
                    elements.setContent(getValue(enAcsParent.getArticleContentId().getPageHtml(), esAcsParent != null ? esAcsParent.getArticleContentId().getPageHtml() : null));
                    elements.setImage(getValue(enAcsParent.getArticleContentId().getImage(), esAcsParent != null ? esAcsParent.getArticleContentId().getImage() : null));
                    elements.setSecondsOfRead(getValue(enAcsParent.getArticleContentId().getSecondsOfRead(), esAcsParent != null ? esAcsParent.getArticleContentId().getSecondsOfRead() : null));
                    elements.setCopyright(getValue(String.format(REFERENCE_COPY_RIGHT, "articles", properties.getName()), esAcsParent != null ? String.format(REFERENCE_COPY_RIGHT, "articles", properties.getName()) : null));
                    properties.setElements(elements);
                    acsParentFragmentDTO.setProperties(properties);
                }
                case VIDEO_FRAGMENT -> {
                    var properties = new Properties(enAcsParent.getTitle(), String.format(CQ_MODEL, "video"), enAcsParent.getTitle(), enAcsParent.getTitle(), enAcsParent.getTags(), null, esAcsParent != null);
                    elements.setVideoType(getValue(enAcsParent.getVideoContentId().getVideoType(), esAcsParent != null ? esAcsParent.getVideoContentId().getVideoType() : null));
                    elements.setVideoDuration(getValue(enAcsParent.getVideoContentId().getVideoDuration(), esAcsParent != null ? esAcsParent.getVideoContentId().getVideoDuration() : null));
                    elements.setVideoUrl(getValue(enAcsParent.getVideoContentId().getVideoUrl(), esAcsParent != null ? esAcsParent.getVideoContentId().getVideoUrl() : null));
                    elements.setVideoCC(getValue(enAcsParent.getVideoContentId().getClosedCaptions(), esAcsParent != null ? esAcsParent.getVideoContentId().getClosedCaptions() : null));
                    elements.setTranscript(getValue(enAcsParent.getVideoContentId().getTranscript(), esAcsParent != null ? esAcsParent.getVideoContentId().getTranscript() : null));
                    elements.setImageUrl(getValue(enAcsParent.getVideoContentId().getImage(), esAcsParent != null ? esAcsParent.getVideoContentId().getImage() : null));
                    elements.setCopyright(getValue(String.format(REFERENCE_COPY_RIGHT, "videos", properties.getName()), esAcsParent != null ? String.format(REFERENCE_COPY_RIGHT, "videos", properties.getName()) : null));
                    properties.setElements(elements);
                    acsParentFragmentDTO.setProperties(properties);
                }
                case AUDIO_FRAGMENT -> {
                    var properties = new Properties(enAcsParent.getTitle(), String.format(CQ_MODEL, "audio"), enAcsParent.getTitle(), enAcsParent.getTitle(), enAcsParent.getTags(), null, esAcsParent != null);
                    elements.setAudioType(getValue(enAcsParent.getAudioContentId().getAudioType(), esAcsParent != null ? esAcsParent.getAudioContentId().getAudioType() : null));
                    elements.setAudioDuration(getValue(enAcsParent.getAudioContentId().getAudioDuration(), esAcsParent != null ? esAcsParent.getAudioContentId().getAudioDuration() : null));
                    elements.setAudioFile(getValue(enAcsParent.getAudioContentId().getAudioUrl(), esAcsParent != null ? esAcsParent.getAudioContentId().getAudioUrl() : null));
                    elements.setTranscript(getValue(enAcsParent.getAudioContentId().getTranscript(), esAcsParent != null ? esAcsParent.getAudioContentId().getTranscript() : null));
                    elements.setImage(getValue(enAcsParent.getAudioContentId().getImage(), esAcsParent != null ? esAcsParent.getAudioContentId().getImage() : null));
                    elements.setCopyright(getValue(String.format(REFERENCE_COPY_RIGHT, "audios", properties.getName()), esAcsParent != null ? String.format(REFERENCE_COPY_RIGHT, "audios", properties.getName()) : null));
                    properties.setElements(elements);
                    acsParentFragmentDTO.setProperties(properties);
                }
                case MASTER_FRAGMENT -> {
                    var properties = new Properties(enAcsParent.getTitle(), String.format(CQ_MODEL, "master-content-fragment"), enAcsParent.getTitle(), enAcsParent.getTitle(), enAcsParent.getTags(), null, esAcsParent != null);
                    elements.setSourceContentID(getValue(enAcsParent.getContentId(), esAcsParent != null ? esAcsParent.getContentId() : null));
                    elements.setContentType(getValue(enAcsParent.getContentType(), esAcsParent != null ? esAcsParent.getContentType() : null));
                    elements.setDescription(getValue(enAcsParent.getDescription(), esAcsParent != null ? esAcsParent.getDescription() : null));
                    elements.setTitle(getValue(enAcsParent.getTitle(), esAcsParent != null ? esAcsParent.getTitle() : null));
                    elements.setSource(getValue(enAcsParent.getSource(), esAcsParent != null ? esAcsParent.getSource() : null));
                    elements.setSourceVersion(getValue(enAcsParent.getSourceVersion(), esAcsParent != null ? esAcsParent.getSourceVersion() : null));
                    elements.setCreatedTime(getValue(enAcsParent.getCreatedTime(), esAcsParent != null ? esAcsParent.getCreatedTime() : null));
                    elements.setModifiedTime(getValue(enAcsParent.getModifiedTime(), esAcsParent != null ? esAcsParent.getModifiedTime() : null));
                    if (ARTICLE.equalsIgnoreCase(enAcsParent.getContentType())) {
                        elements.setArticle(getValue(String.format(PARENT_REFERENCE, "articles", properties.getName()), esAcsParent != null ? String.format(PARENT_REFERENCE, "articles", properties.getName()) : null));
                    } else if (VIDEO.equalsIgnoreCase(enAcsParent.getContentType())) {
                        elements.setVideo(getValue(String.format(PARENT_REFERENCE, "videos", properties.getName()), esAcsParent != null ? String.format(PARENT_REFERENCE, "videos", properties.getName()) : null));
                    } else if (AUDIO.equalsIgnoreCase(enAcsParent.getContentType())) {
                        elements.setAudio(getValue(String.format(PARENT_REFERENCE, "audios", properties.getName()), esAcsParent != null ? String.format(PARENT_REFERENCE, "audios", properties.getName()) : null));
                    }
                    properties.setElements(elements);
                    acsParentFragmentDTO.setProperties(properties);
                }
            }
            return acsParentFragmentDTO;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }

//    public AcsContentIngestLogs startTheJob(AcsParent acsParent) {
//        return acsContentIngestLogsRepo.save(getAcsContentIngestLogs(acsParent, false));
//    }

//    public AcsContentIngestLogs endTheJobWithSuccess(AcsContentIngestLogs acsContentIngestLogs) {
//        acsContentIngestLogs.setStatus(Boolean.TRUE);
//        acsContentIngestLogsRepo.save(acsContentIngestLogs);
//        return acsContentIngestLogs;
//    }

//    private AcsContentIngestLogs endTheJobWithFail(AcsContentIngestLogs acsContentIngestLogs, String message) {
//        acsContentIngestLogs.setStatus(Boolean.FALSE);
//        acsContentIngestLogsRepo.save(acsContentIngestLogs);
//        acsExceptionRepo.save(getAcsException(acsContentIngestLogs, message));
//        LOGGER.error(message);
//        return acsContentIngestLogs;
//    }

//    private AcsContentIngestLogs getAcsContentIngestLogs(AcsParent acsParent, Boolean status) {
//        return AcsContentIngestLogs.builder()
//                .contentId(acsParent.getId())
//                .sourceContentId(acsParent.getContentId())
//                .contentType(acsParent.getContentType())
//                .source(acsParent.getSource())
//                .status(status)
//                .build();
//    }

//    private AcsException getAcsException(AcsContentIngestLogs acsContentIngestLog, String errorMessage) {
//        return AcsException.builder()
//                .jobId(acsContentIngestLog.getJobId())
//                .message(errorMessage)
//                .createdTime(Instant.now())
//                .build();
//    }

    public static <T> Value<T> getValue(T value, T spanishValue) {
        var newValue = new Value<T>();
        newValue.setValue(value);
        if (spanishValue != null) {
            Variations<T> variations = new Variations<>();
            variations.setEs(new Value<T>(spanishValue, null));
            newValue.setVariations(variations);
        }
        return newValue;
    }

    public ServiceResponse<Integer> postDataToACS(Object data, String bearerToken, String url, Boolean isForUpdate) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + bearerToken);
        headers.add("Content-Type", "application/json");
        try {
            ResponseEntity<String> response1 = !isForUpdate ?
                    restTemplate.postForEntity(url, new HttpEntity<>(data, headers), String.class) :
                    restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(data, headers), String.class);
            String statusCode = StringEscapeUtils.escapeHtml4(response1.getStatusCode().toString());
            statusCode = statusCode.substring(0, 3);
            LOGGER.info(statusCode);
            return new ServiceResponse<Integer>().success(Integer.valueOf(statusCode));
        } catch (Exception e) {
            try {
                String proxyHost = serviceConfiguration.proxyHost;
                int proxyPort = serviceConfiguration.proxyPort;
                String proxyUser = getUName();
                String proxyPassword = getUPwd();
                Authenticator.setDefault(new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
                    }
                });
                Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
                SimpleClientHttpRequestFactory fact = new SimpleClientHttpRequestFactory();
                fact.setProxy(proxy);
                restTemplate = new RestTemplate(fact);
                ResponseEntity<String> response = !isForUpdate ?restTemplate.postForEntity(url, new HttpEntity<>(data, headers), String.class)
                        : restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(data, headers), String.class);
                String statusCode = StringEscapeUtils.escapeHtml4(response.getStatusCode().toString());
                statusCode = statusCode.substring(0, 3);
                LOGGER.info(statusCode);
                return new ServiceResponse<Integer>().success(Integer.valueOf(statusCode));
            } catch (Exception e1) {
                return new ServiceResponse<Integer>().error(e1.getMessage(), HttpStatus.BAD_GATEWAY);
            }
        }
    }

    public String getUName() {
        return credentialsManagerService.decrypt(serviceConfiguration.proxyUserName);
    }

    public String getUPwd() {
        return credentialsManagerService.decrypt(serviceConfiguration.proxyUserPassword);
    }

    public String getAccessToken() throws Exception {
        String privateKeyPath = serviceConfiguration.acsPrivateKeyPath;
        String orgId = serviceConfiguration.acsOrgId;
        String techAccountId = serviceConfiguration.acsTechAccountId;
        String clientId = serviceConfiguration.acsClientId;
        String clientSecret = serviceConfiguration.acsClientSecret;
        String jwtToken = generateJWT(orgId, techAccountId, clientId, privateKeyPath);
        return getAccessToken(clientId, clientSecret, jwtToken);
    }

    private PrivateKey loadPrivateKey(String keyPath) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        String privateKeyPEM = new String(keyPath)
                .replace("-----BEGIN RSA PRIVATE KEY-----", "")
                .replace("-----END RSA PRIVATE KEY-----", "")
                .replaceAll("\\s+", "");

        byte[] decoded = Base64.getDecoder().decode(privateKeyPEM);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decoded);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(keySpec);
    }

    private String generateJWT(String orgId, String techAccountId, String clientId, String privateKeyPath) throws Exception {
        PrivateKey privateKey = loadPrivateKey(privateKeyPath);

        Map<String, Object> claims = new HashMap<>();
        claims.put("iss", orgId);
        claims.put("sub", techAccountId);
        claims.put("exp", Instant.now().getEpochSecond() + 3600); // 1-hour expiration
        claims.put("aud", "https://ims-na1.adobelogin.com/c/" + clientId);
        claims.put("https://ims-na1.adobelogin.com/s/ent_aem_cloud_api", true);

        return Jwts.builder()
                .setClaims(claims)
                .signWith(privateKey, io.jsonwebtoken.SignatureAlgorithm.RS256)
                .compact();
    }

    private String getAccessToken(String clientId, String clientSecret, String jwtToken) throws Exception {
        String url = "https://ims-na1.adobelogin.com/ims/exchange/jwt/";

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(url);
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair("client_id", clientId));
            params.add(new BasicNameValuePair("client_secret", clientSecret));
            params.add(new BasicNameValuePair("jwt_token", jwtToken));
            post.setEntity(new UrlEncodedFormEntity(params));

            try (CloseableHttpResponse response = httpClient.execute(post)) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode jsonResponse = mapper.readTree(response.getEntity().getContent());
                return jsonResponse.get("access_token").asText();
            }
        }
    }


}
