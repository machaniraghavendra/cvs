package com.acs.content_ingest.impl;

import com.acs.content_ingest.config.ServiceConfiguration;
import com.acs.content_ingest.dto.*;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.exceptions.JsonReadWriteException;
import com.acs.content_ingest.exceptions.ReaderException;
import com.acs.content_ingest.interfaces.CredentialsManagerService;
import com.acs.content_ingest.interfaces.HealthWiseDataToDb;
import com.acs.content_ingest.interfaces.MeredithRecipeToDbService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import static com.acs.content_ingest.constents.ApplicationMessage.*;

@Service
@Slf4j
public class MeredithRecipeToDbServiceImpl implements MeredithRecipeToDbService {

    @Autowired
    private ServiceConfiguration serviceConfiguration;

    @Autowired
    private CredentialsManagerService credentialsManager;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    MeredithArticleToDbServiceImpl meredithArticleToDbService;

    @Autowired
    private HealthWiseDataToDb healthWiseDataToDb;

    @Autowired
    private HealthWiseContentIngestServiceImpl healthWiseContentIngestService;

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ServiceResponse<List<AcsParent>> saveAllMeredithRecipeDataToDb(String lang) {
        try {
            var result = getAllMeredithRecipes("ASC", "id", 0, lang);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(result.getResult());
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            LOGGER.error("Error in saveAllMeredithRecipeDataToDb - {}", e.getMessage(), e);
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional(rollbackOn = Exception.class)
    public ServiceResponse<List<AcsParent>> saveMeredithRecipeDataToDb(String id, String lang) {
        try {
            if (healthWiseContentIngestService.isRecordAlreadyPresent(id, lang)) {
                return new ServiceResponse<List<AcsParent>>().error("Record already present in DB docId :" + id + "and lang : " + lang, HttpStatus.BAD_REQUEST);
            }
            var result = getMeredithRecipeData(id, lang, null);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(List.of(result.getResult()));
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            LOGGER.error("Error in saveMeredithRecipeDataToDb - {}", e.getMessage(), e);
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ServiceResponse<List<HealthWiseDto>> getAllMeredithRecipes(String order, String sort_by, int page, String lang) {
        try {
            var meredithRecipes = new ArrayList<HealthWiseDto>();
            String jsonDataSpanish = null;
            if (lang.equalsIgnoreCase(ES_US)) {
                jsonDataSpanish = getMeredithRecipeJsonData("", SPANISH, order, sort_by, page);
            }
            var listOfIdsResponse = getAllMeredithRecipeIds(order, sort_by, page, lang, jsonDataSpanish);
            if (listOfIdsResponse.getIsSuccess() && !listOfIdsResponse.getResult().isEmpty()) {
                String finalJsonDataSpanish = jsonDataSpanish;
                listOfIdsResponse.getResult().forEach(id -> meredithRecipes.add(getMeredithRecipeData(id, lang, finalJsonDataSpanish).getResult()));
            }
            return new ServiceResponse<List<HealthWiseDto>>().success(meredithRecipes);
        } catch (Exception e) {
            LOGGER.error("Error in getAllMeredithRecipes - {}", e.getMessage(), e);
            return new ServiceResponse<List<HealthWiseDto>>().error(e.getMessage());
        }
    }

    @Override
    public ServiceResponse<HealthWiseDto> getMeredithRecipeData(@NotNull String id, @NotNull String language, String jsonDataSpanish) {
        var healthWiseDto = new HealthWiseDto();
        if (!(language.equalsIgnoreCase(EN_US) || language.equalsIgnoreCase(ES_US))) {
            return new ServiceResponse<HealthWiseDto>().error("Language Parameter Must be en-us or es-us", HttpStatus.BAD_REQUEST);
        }
        try {
            String meredithJsonData;
            if (language.equalsIgnoreCase(EN_US)) {
                meredithJsonData = getMeredithRecipeJsonData(id, ENGLISH, null, null, 0);
            } else {
                meredithJsonData = jsonDataSpanish == null ? getMeredithRecipeJsonData(id, SPANISH, null, null, 0) : jsonDataSpanish;
            }
            if (meredithJsonData != null) {
                var rootNode = objectMapper.readTree(meredithJsonData);
                var rootNodeData = rootNode.get(language.equalsIgnoreCase(EN_US) ? "result" : "recipes");
                if (language.equalsIgnoreCase(ES_US)) {
                    rootNodeData = meredithArticleToDbService.getSpanishDataJsonDataForId(id, rootNodeData);
                }
                healthWiseDto.setContentId(Objects.requireNonNull(rootNodeData.get("id")).asText());
                healthWiseDto.setContentType(RECIPE);
                healthWiseDto.setTitle(Objects.requireNonNull(rootNodeData.get("title")).asText());
                healthWiseDto.setDescription(healthWiseDto.getTitle());
                healthWiseDto.setLanguage(language);
                healthWiseDto.setSource(Objects.requireNonNull(rootNodeData.get("contentProvider")).asText());
                var createdAt = rootNodeData.get("createdAt").asText();
                var updatedAt = rootNodeData.get("updatedAt").asText();
                healthWiseDto.setCreatedTime(createdAt.substring(0, createdAt.indexOf("T")));
                healthWiseDto.setModifiedTime(updatedAt.substring(0, updatedAt.indexOf("T")));
                healthWiseDto.setTags(List.of(
                        "ahm:MAH Tags/Topic/Recipes/Recipe",
                        "ahm:MAH Tags/Gender/Male",
                        "ahm:MAH Tags/Gender/Female",
                        "ahm:MAH Tags/Age/Childhood",
                        "ahm:MAH Tags/Age/Teen",
                        "ahm:MAH Tags/Age/Adult",
                        "ahm:MAH Tags/Age/Senior"
                ));
                healthWiseDto.setCredits("Dotdash Meredith");
                healthWiseDto.setDisclaimer("<div><p> </p></div>");
                healthWiseDto.setIngredientGroups(objectMapper.treeToValue(Objects.requireNonNull(rootNodeData.get("ingredientGroups")), IngredientGroups[].class));
                healthWiseDto.setPreparationTime(objectMapper.treeToValue(Objects.requireNonNull(rootNodeData.get("totalTime")), TotalTime.class).getMinutes() * 60);
                healthWiseDto.setCalories(getCalorieNutrition(rootNodeData, language.equalsIgnoreCase(ES_US)) == null ? null : BigDecimal.valueOf(getCalorieNutrition(rootNodeData, language.equalsIgnoreCase(ES_US)).getAmount()));
                healthWiseDto.setInstructions(getInstructions(rootNodeData));
                healthWiseDto.setInformation(Objects.requireNonNull(rootNodeData.get("description")).asText());
                healthWiseDto.setImage(getImage(rootNodeData));
                healthWiseDto.setSecondsOfRead(healthWiseContentIngestService.getEstimatedReadTime(healthWiseDto.getInstructions()) * 60);
                return new ServiceResponse<HealthWiseDto>().success(healthWiseContentIngestService.sanitizeHealthWiseData(healthWiseDto));
            } else {
                throw new IOException("There is no data available from the HealthWise API for the id : " + id);
            }
        } catch (Exception e) {
            LOGGER.error("Error in getMeredithRecipeData - {}", e.getMessage(), e);
            return new ServiceResponse<HealthWiseDto>().error(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private ServiceResponse<List<String>> getAllMeredithRecipeIds(String order, String sort_by, int page, String lang, String jsonDataSpanish) {
        var response = getAllMeredithRecipes(order, sort_by, page, lang, jsonDataSpanish);
        if (response.getIsSuccess()) {
            List<String> ids = new ArrayList<>();
            var result = response.getResult();
            IntStream.of(0, result.size()).forEach(i -> ids.add(result.get(i).get("id").asText()));
            return new ServiceResponse<List<String>>().success(ids);
        }
        return new ServiceResponse<List<String>>().error(response.getErrorMessage());
    }

    public ServiceResponse<List<JsonNode>> getAllMeredithRecipes(String order, String sort_by, int page, String lang, String jsonDataSpanish) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            List<JsonNode> meredithRecipes = new ArrayList<>();
            boolean terminate = true;
            lang = lang.toLowerCase();
            do {
                String jsonData = lang.equalsIgnoreCase(EN_US) ? getMeredithRecipeJsonData("", ENGLISH, order, sort_by, page) : jsonDataSpanish;
                String recipeType = Objects.nonNull(lang) && Objects.equals(EN_US, lang) ? "result" : "recipes";
                try {
                    JsonNode rootNode = objectMapper.readTree(jsonData);
                    if (rootNode.get(recipeType).isEmpty() || rootNode.get(recipeType).size() == 0) {
                        terminate = false;
                    } else {
                        for (int i = 0; i < rootNode.get(recipeType).size(); i++) {
                            meredithRecipes.add(rootNode.get(recipeType).get(i));
                            if (Objects.equals(ES_US, lang) && terminate && i == rootNode.get(recipeType).size() - 1) {
                                terminate = false;
                            }
                        }
                    }
                    page++;
                } catch (JsonProcessingException e) {
                    LOGGER.error((e.getMessage()));
                    throw new RuntimeException(e);
                }
            } while (terminate);
            LOGGER.info("Number of ids :{}", meredithRecipes.size());
            return new ServiceResponse<List<JsonNode>>().success(meredithRecipes);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return new ServiceResponse<List<JsonNode>>().error(e.getMessage());
        }
    }

    private String getImage(JsonNode rootNodeData) throws JsonProcessingException {
        var images = objectMapper.treeToValue(rootNodeData.get("images"), Image[].class)[0];
        return images.getImageCrops().getStandard().getLarge().getUri();
    }

    private String getInstructions(JsonNode rootNodeData) throws JsonProcessingException {
        var instructions = objectMapper.treeToValue(rootNodeData.get("instructions"), Instructions[].class);
        var point = 1;
        var text = new StringBuilder();
        for (var instruction : instructions) {
            text.append(point++).append(". ").append(instruction.getText() + "\n\n");
        }
        return text.toString();
    }

    private Nutrition getCalorieNutrition(JsonNode rootNodeData, Boolean isSpanish) throws JsonProcessingException {
        var name = isSpanish ? "Calorías" : "Calories";
        var nutritions = objectMapper.treeToValue(Objects.requireNonNull(rootNodeData.get("nutrition")), Nutrition[].class);
        return Arrays.stream(nutritions).filter(n -> name.equalsIgnoreCase(n.getName())).findFirst().orElse(null);
    }

    private String getMeredithRecipeJsonData(String id, String lang, String order, String sort_by, int page) throws IOException {
        URL url = null;
        try {
            if (!StringUtils.hasLength(id)) {
                if (lang.equalsIgnoreCase(ENGLISH)) {
                    url = new URL(serviceConfiguration.meredithRecipeUrl + "?sort_by=" + sort_by + "&order=" + order +
                            "&page=" + page + "&per_page=100");
                } else if (lang.equalsIgnoreCase(SPANISH)) {
                    url = new URL(serviceConfiguration.spanishRecipeUrl);

                }
            } else {
                if (lang.equalsIgnoreCase(ENGLISH)) {
                    url = new URL(serviceConfiguration.meredithRecipeUrl + "/" + id);
                } else if (lang.equalsIgnoreCase(SPANISH)) {
                    url = new URL(serviceConfiguration.spanishRecipeUrl);
                }
            }

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            LOGGER.info("Connection object: " + connection.getURL());
            connection.setRequestMethod("GET");
            connection.setRequestProperty("X-API-KEY", credentialsManager.decrypt(serviceConfiguration.apiKey));
            connection.setRequestProperty("X-HW-Version", "2");
            connection.setRequestProperty("Accept", "application/json");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    LOGGER.info("Content received from the meredith without the proxy server");
                    String inputLine;
                    StringBuilder response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    return response.toString();
                }
            } else {
                LOGGER.info("Request failed with response code (without proxy server): " + responseCode);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
            String proxyHost = serviceConfiguration.proxyHost;
            int proxyPort = serviceConfiguration.proxyPort;
            String proxyUser = getUName();
            String proxyPassword = getUPwd();
            Authenticator.setDefault(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
                }
            });
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
//            if(url==null) {
//                if (!(StringUtils.isEmpty(order) && StringUtils.isEmpty(sort_by))) {
//                    url = new URL("https://api.meredithcontentlicensing.com/v0/recipes" + "?sort_by=" + sort_by + "&order=" + order +
//                            "&page=" + page + "&per_page=100");
//                } else {
//                    url = new URL(serviceConfiguration.meredithRecipeUrl + id);
//                }
//            }
            HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);
            connection.setRequestProperty("X-API-KEY", credentialsManager.decrypt(serviceConfiguration.apiKey));
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();
            while (true) {
                try {
                    if ((line = reader.readLine()) == null) break;
                } catch (IOException e) {
                    throw new JsonReadWriteException(e);
                }
                response.append(line);
            }
            try {
                reader.close();
            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
                throw new ReaderException(e);
            }
            connection.disconnect(); // check if closed successfully or not
            return response.toString();
        }
        return null;
    }

    private String getUName() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserName);
    }

    private String getUPwd() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserPassword);
    }
}
