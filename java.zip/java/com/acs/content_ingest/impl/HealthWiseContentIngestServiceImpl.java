package com.acs.content_ingest.impl;

import com.acs.content_ingest.config.ServiceConfiguration;
import com.acs.content_ingest.dto.*;
import com.acs.content_ingest.dto.content_fragment_dtos.AhspDescription;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.exceptions.JsonReadWriteException;
import com.acs.content_ingest.exceptions.ReaderException;
import com.acs.content_ingest.interfaces.HealthWiseContentIngestService;
import com.acs.content_ingest.interfaces.HealthWiseDataToDb;
import com.acs.content_ingest.repository.AcsParentRepo;
import com.acs.content_ingest.repository.ExploreArticleImagesRepo;
import com.acs.content_ingest.repository.ExploreCategoryRepo;
import com.acs.content_ingest.repository.ExploreImageRepo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.safety.Cleaner;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.math.BigDecimal;
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ch.qos.logback.core.util.StringUtil.capitalizeFirstLetter;
import static com.acs.content_ingest.constents.ApplicationMessage.*;
import static org.apache.commons.io.IOUtils.resourceToString;

@Service
@Slf4j
public class HealthWiseContentIngestServiceImpl implements HealthWiseContentIngestService {

    @Autowired
    private ServiceConfiguration serviceConfiguration;

    @Autowired
    private CredentialsManagerServiceImpl credentialsManager;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ExploreCategoryRepo exploreCategoryRepo;

    @Autowired
    private ExploreImageRepo exploreImageRepo;

    @Autowired
    private ExploreArticleImagesRepo exploreArticleImagesRepo;

    @Autowired
    private HealthWiseDataToDb healthWiseDataToDb;

    @Autowired
    private AcsParentRepo acsParentRepo;

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveAllContentTypes(String contentType, String lang) {
        try {
            var result = getAllHealthWiseArticleVideoData(contentType, lang);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(result.getResult());
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveHealthWiseData(String id, String lang) {
        try {
            if (isRecordAlreadyPresent(id, lang)) {
                return new ServiceResponse<List<AcsParent>>().error("Record already present in DB docId :" + id + "and lang : " + lang, HttpStatus.BAD_REQUEST);
            }
            var result = getHealthWiseArticleVideoData(id, lang, Collections.emptyList());
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(List.of(result.getResult()));
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveAllAudioContent(String lang) {
        try {
            ServiceResponse<List<HealthWiseDto>> result = getAllAudioContent(lang);
            if (result.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(result.getResult());
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(result.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public Boolean isRecordAlreadyPresent(String id, String lang) {
        return acsParentRepo.findByContentIdAndLanguageIgnoreCase(id, lang).isPresent();
    }

    @Override
    @Transactional
    public ServiceResponse<List<AcsParent>> saveAudioContent(String id, String lang) {
        try {
            if (isRecordAlreadyPresent(id, lang)) {
                return new ServiceResponse<List<AcsParent>>().error("Record already present");
            }
            var audioResponse = getAudioContent(id, lang, null);
            if (audioResponse.getIsSuccess()) {
                var response = healthWiseDataToDb.saveAllAcsParent(List.of(audioResponse.getResult()));
                if (response.getIsSuccess()) {
                    return new ServiceResponse<List<AcsParent>>().success(response.getResult());
                } else {
                    throw new HealthWiseException(response.getErrorMessage());
                }
            } else {
                throw new HealthWiseException(audioResponse.getErrorMessage());
            }
        } catch (Exception e) {
            return new ServiceResponse<List<AcsParent>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ServiceResponse<List<HealthWiseDto>> getAllAudioContent(String lang) {
        try {
            var rootNode = getAudioJsonData();
            var healthWiseDtos = new ArrayList<HealthWiseDto>();
            if (EN_US.equalsIgnoreCase(lang)) {
                healthWiseDtos.addAll(getListOfHealthWiseDtosWithLang(lang, "English Topics", rootNode));
            } else if (ES_US.equalsIgnoreCase(lang)) {
                healthWiseDtos.addAll(getListOfHealthWiseDtosWithLang(lang, "Spanish Topics", rootNode));
            }
            return new ServiceResponse<List<HealthWiseDto>>().success(healthWiseDtos);
        } catch (Exception e) {
            return new ServiceResponse<List<HealthWiseDto>>().error(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private List<HealthWiseDto> getListOfHealthWiseDtosWithLang(String lang, String fieldName, JsonNode rootNode) {
        var healthWiseDto = new ArrayList<HealthWiseDto>();
        for (JsonNode jsonNode : rootNode.get(fieldName)) {
            var id = jsonNode.get("script").asText();
            if (!isRecordAlreadyPresent(id, lang)) {
                if (ES_US.equalsIgnoreCase(lang)) {
                    id = id.replace("_ES", "");
                }
                var response = getAudioContent(id, lang, rootNode);
                if (response.getIsSuccess()) {
                    healthWiseDto.add(response.getResult());
                } else {
                    LOGGER.error(response.getErrorMessage() + " where id : {}", id);
                }
            }
        }
        return healthWiseDto;
    }

    @Override
    public ServiceResponse<List<HealthWiseDto>> getAllHealthWiseArticleVideoData(String contentType, String lang) {
        var inventoryData = getInventoryDataBasedOnContentType(null, Boolean.TRUE, contentType);
        if (!inventoryData.isEmpty()) {
            var listOfInventoryIds = inventoryData.stream().map(InventoryExtract::getHwid).toList();
            var healthWiseDtos = new ArrayList<HealthWiseDto>();
            for (var hwid : listOfInventoryIds) {
                if (!isRecordAlreadyPresent(hwid, lang)) {
                    var response = getHealthWiseArticleVideoData(hwid, lang, inventoryData);
                    if (response.getIsSuccess()) {
                        healthWiseDtos.add(response.getResult());
                    } else {
                        LOGGER.error(response.getErrorMessage());
                    }
                }
            }
            return new ServiceResponse<List<HealthWiseDto>>().success(healthWiseDtos);
        }
        return new ServiceResponse<List<HealthWiseDto>>().error("Something went wrong", HttpStatus.BAD_REQUEST);
    }

    @Override
    public ServiceResponse<HealthWiseDto> getHealthWiseArticleVideoData(@NotNull String docId, @NotNull String language, List<InventoryExtract> inventoryExtracts) {
        var healthWiseDto = new HealthWiseDto();
        if (!(language.equalsIgnoreCase(EN_US) || language.equalsIgnoreCase(ES_US))) {
            return new ServiceResponse<HealthWiseDto>().error("Language Parameter Must be en-us or es-us", HttpStatus.BAD_REQUEST);
        }

        try {
            String healthWiseJsonData = getHealthWiseArticleVideoJsonDataByIdAndLang(docId, language);
            if (healthWiseJsonData != null) {
                var rootNode = objectMapper.readTree(healthWiseJsonData);
                var rootNodeData = rootNode.get("data");
                if (language.equalsIgnoreCase(rootNodeData.get("lang").asText())) {
                    healthWiseDto.setContentId(Objects.requireNonNull(rootNodeData.get("id")).asText());
                    healthWiseDto.setContentType(getContentType(rootNodeData));
                    healthWiseDto.setTitle(Objects.requireNonNull(rootNodeData.get("title").get("consumer")).asText());
                    healthWiseDto.setDescription(Objects.requireNonNull(rootNodeData.get("abstract").get("consumer")).asText());
                    healthWiseDto.setLanguage(Objects.requireNonNull(rootNodeData.get("lang")).asText());
                    healthWiseDto.setSource("HealthWise");
                    healthWiseDto.setSourceVersion(BigDecimal.valueOf(Objects.requireNonNull(rootNodeData.get("version")).asDouble()));
                    healthWiseDto.setCreatedTime(rootNodeData.has("certifiedDate") ? Objects.requireNonNull(rootNodeData.get("certifiedDate")).asText() : LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                    healthWiseDto.setModifiedTime(healthWiseDto.getCreatedTime());
                    // Getting inventory extract based on content type or based on docId
                    var inventoryExtract = getInventoryExtractData(healthWiseDto.getContentType(), docId, Boolean.FALSE, inventoryExtracts);
                    var listOfTags = getTagsFromInventoryData(healthWiseDto, inventoryExtract);
                    healthWiseDto.setTags(listOfTags);
                    var topics = Objects.requireNonNull(rootNodeData.get("topics"));
                    healthWiseDto.setPageHtml(topics.has(0) ? topics.get(0).get("html").asText() : null);
                    healthWiseDto.setCredits(rootNodeData.has("credits") ? Objects.requireNonNull(rootNodeData.get("credits").get("author").get("name")).asText() : (EN_US.equalsIgnoreCase(language) ? CREDITS_EN : CREDITS_ES));
                    healthWiseDto.setDisclaimer(rootNodeData.has("legal") ? Objects.requireNonNull(rootNodeData.get("legal").get("disclaimer")).asText() : (EN_US.equalsIgnoreCase(language) ? DISCLAIMER_EN : DISCLAIMER_ES));
                    healthWiseDto.setSecondsOfRead(getEstimatedReadTime(healthWiseDto.getPageHtml()) * 60);
                    if (VIDEO.equalsIgnoreCase(healthWiseDto.getContentType())) {
                        healthWiseDto.setVideoUrl(rootNodeData.get("sources").get("mp4_1080p_url").asText());
                        healthWiseDto.setClosedCaptions(rootNodeData.get("closedCaptions").get("srt_url").asText());
                        if (rootNodeData.has("duration")) {
                            healthWiseDto.setVideoDuration(convertMinutesToSeconds(rootNodeData.get("duration").asText()));
                        } else {
                            LOGGER.warn("No video duration is coming from healthWise api for the id : " + docId);
                        }
                        if (rootNodeData.has("thumbnailImage")) {
                            healthWiseDto.setImage(rootNodeData.get("thumbnailImage").asText().split("\"")[1]);
                        } else {
                            LOGGER.warn("No video image is coming from healthWise api for the id : " + docId);
                        }
                        healthWiseDto.setVideoType("external");
                        healthWiseDto.setTranscript(rootNodeData.get("transcript").get("html").asText());
                    } else if (ARTICLE.equalsIgnoreCase(healthWiseDto.getContentType())) {
                        healthWiseDto.setImage(getImageUrlWithCategory(inventoryExtract.getCategories().getEnUs().get(0).getDescription()));
                    }
                } else {
                    throw new IOException("Exception occurred as we are getting English content for spanish ingestion from healthWise api for id : " + docId);
                }
                return new ServiceResponse<HealthWiseDto>().success(sanitizeHealthWiseData(healthWiseDto));
            } else {
                throw new IOException("There is no data available from the HealthWise API for the id : " + docId);
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage() + docId);
            return new ServiceResponse<HealthWiseDto>().error(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    public String getHealthWiseArticleVideoJsonDataByIdAndLang(String docId, String language) throws IOException {
        var healthWiseArticleVideoUrl = serviceConfiguration.healthwiseUrl + docId + "/" + language;
        var healthWiseAccessToken = healthWiseAccessTokenGeneration();
        var healthWiseJsonData = getHealthWiseArticleVideoJsonData(healthWiseAccessToken, healthWiseArticleVideoUrl);
        return healthWiseJsonData;
    }

    public int getEstimatedReadTime(String htmlContent) {

        int minutes = 0;
        String maxSuffix = " max read";
        double maxReadTime = 0;

        if (!htmlContent.isEmpty()) {
            int wordCount = htmlContent.replaceAll("\\<.*?\\>", "").replace("&nbsp;", " ").split("\\s+").length;
            maxReadTime = (double) wordCount / 130;
            if (maxReadTime < 0.15) {
                maxReadTime = 1;
            } else {
                double maxReadTimeFloatNum = maxReadTime - (long) maxReadTime;
                maxReadTime = maxReadTimeFloatNum > 0.15 ? Math.ceil(maxReadTime) : Math.round(maxReadTime);
            }
        }
        minutes = (int) maxReadTime;
        return minutes;
    }


    public String getImageUrlWithCategory(String category) {
        try {
            var exploreArticleImages = exploreArticleImagesRepo.findAllByCategory(category);
            if (exploreArticleImages.isPresent()) {
                var imageUrl = exploreArticleImages.orElseThrow(() -> new RuntimeException()).get(new Random().nextInt(0, exploreArticleImages.get().size())).getImageUrl();
                return serviceConfiguration.baseUrlForImage + imageUrl;
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    private List<String> getTagsFromInventoryData(HealthWiseDto healthWiseDto, InventoryExtract inventoryExtract) {
        var listOfTags = new ArrayList<String>();
        for (var inventory : inventoryExtract.getCategories().getEnUs()) {
            var exploreCategory = exploreCategoryRepo.findByCodeIgnoreCase(String.valueOf(inventory.getDescription()));
            if (exploreCategory != null && exploreCategory.getExploreTopicId() != null) {
                listOfTags.add("ahm:MAH Tags/Topic/" + exploreCategory.getExploreTopicId().getCode() + "/" + exploreCategory.getCode());
            }
        }
        inventoryExtract.getAge().stream().forEach(age -> listOfTags.add("ahm:MAH Tags/Age/" + age));
        inventoryExtract.getGender().stream().forEach(gender -> listOfTags.add("ahm:MAH Tags/Gender/" + capitalizeFirstLetter(gender)));
        listOfTags.add("ahm:MAH Tags/Content Type/" + capitalizeFirstLetter(healthWiseDto.getContentType()));
        return listOfTags;
    }

    private InventoryExtract getInventoryExtractData(String contentType, String docId, Boolean hasToReadAllInventory, List<InventoryExtract> inventoryExtracts) {
        return (inventoryExtracts.isEmpty() ? getInventoryDataBasedOnContentType(docId, hasToReadAllInventory, contentType).stream() : inventoryExtracts.stream())
                .filter(inventoryExtract -> docId.equalsIgnoreCase(inventoryExtract.getHwid())).findFirst().orElseThrow();
    }

    @Override
    public List<InventoryExtract> getInventoryDataBasedOnContentType(String docId, Boolean hasToReadAllInventory, String contentType) {
        // Here we will get list of all inventory data from api.
        var inventoryDataFromHealthwise = getInventoryDataFromHealthwise(docId, hasToReadAllInventory);
        if (!(inventoryDataFromHealthwise.isEmpty())) {
            return inventoryDataFromHealthwise.stream().filter(inventoryExtract -> {
                        var isVideo = "multimedia".equalsIgnoreCase(inventoryExtract.getType())
                                && VIDEO.equalsIgnoreCase(inventoryExtract.getSubType());
                        if (VIDEO.equalsIgnoreCase(contentType) && isVideo) return true;
                        if (ARTICLE.equalsIgnoreCase(contentType) && !isVideo) return true;
                        return false;
                    }
            ).toList();
        }
        return Collections.emptyList();
    }

    private String getContentType(JsonNode rootNodeData) {
        var docType = Objects.requireNonNull(rootNodeData.get("docType")).asText();
        var type = Objects.requireNonNull(rootNodeData.get("type")).asText();
        //TODO: Make these hardcoded values into constant values
        return ("multimedia".equalsIgnoreCase(docType) && VIDEO.equalsIgnoreCase(type)) ? VIDEO : ARTICLE;
    }

    @Override
    public List<InventoryExtract> getInventoryDataFromHealthwise(String docId, Boolean hasToMapAllData) {
        int count = 0;
        int skip = 0;
        var inventoryExtracts = new ArrayList<InventoryExtract>();
        while (count == 0) {
            try {
                var url = String.format(serviceConfiguration.healthwiseInventoryUrl, skip);
                var inventoryJsonData = getHealthWiseArticleVideoJsonData(healthWiseAccessTokenGeneration(), url);
                try {
                    var jsonNode = objectMapper.readTree(inventoryJsonData);
                    var inventoryData = objectMapper.treeToValue(jsonNode.get("data").get("inventory"), InventoryExtract[].class);
                    var pagination = objectMapper.treeToValue(jsonNode.get("data").get("pagination"), Pagination.class);
                    count = pagination.getCount() == 1000 ? 0 : pagination.getCount();
                    for (InventoryExtract inventory : inventoryData) {
                        if (hasToMapAllData || inventory.getHwid().equalsIgnoreCase(docId)) {
                            try {
                                InventoryExtract inventoryExtract = new InventoryExtract();
                                inventoryExtract.setHwid(inventory.getHwid());
                                inventoryExtract.setGender(inventory.getGender());
                                inventoryExtract.setMaxAge(inventory.getMaxAge());
                                inventoryExtract.setMinAge(inventory.getMinAge());
                                inventoryExtract.setType(inventory.getType());
                                var categories = inventory.getCategories();
                                if ("ashp".equalsIgnoreCase(inventoryExtract.getType())){
                                    categories = getCategoryFromAhspTagsFile(inventoryExtract.getHwid());
                                    inventoryExtract.setMinAge("0");
                                    inventoryExtract.setMaxAge("110");
                                }
                                inventoryExtract.setCategories(categories);
                                inventoryExtract.setSubType(inventory.getSubType());
                                var age = new ArrayList<String>();
                                if (Objects.nonNull(inventoryExtract.getMinAge()) && Objects.nonNull(inventoryExtract.getMaxAge())) {
                                    var minAge = Integer.valueOf(inventoryExtract.getMinAge());
                                    var maxAge = Integer.valueOf(inventoryExtract.getMaxAge());
                                    if ((minAge >= Integer.valueOf(0) && minAge <= Integer.valueOf(12)) || (maxAge >= Integer.valueOf(0) && maxAge <= 12)) {
                                        age.add("Childhood");
                                    }
                                    if ((minAge >= Integer.valueOf(13) && minAge <= Integer.valueOf(19)) && ((maxAge >= 13 && maxAge <= 19) || (maxAge >= 20 && maxAge <= 60) || (maxAge >= 60 && maxAge <= 110))) {
                                        age.add("Teen");
                                    }
                                    if ((minAge >= Integer.valueOf(20) && minAge <= Integer.valueOf(60)) || ((maxAge >= 20 || maxAge <= 60) || (maxAge >= 60 && maxAge <= 110))) {
                                        age.add("Adult");
                                    }
                                    if ((minAge >= Integer.valueOf(60) && minAge <= Integer.valueOf(110)) || (maxAge >= 60 && maxAge <= 110)) {
                                        age.add("Senior");
                                    }
                                }
                                inventoryExtract.setAge(age);
                                if (inventoryExtract.getMaxAge() != null && inventoryExtract.getMinAge() != null
                                        && inventoryExtract.getGender() != null && !inventoryExtract.getGender().isEmpty()
                                        && !inventoryExtract.getCategories().getEnUs().isEmpty() && inventoryExtract.getCategories().getEnUs() != null) {
                                    inventoryExtracts.add(inventoryExtract);
                                }
                            } catch (Exception e) {
                                LOGGER.error(e.getMessage());
                            }
                        }
                    }
                } catch (Exception e) {
                    LOGGER.error(e.getMessage());
                }
            } catch (Exception e) {
                LOGGER.error(e.getMessage());
            }
            skip += 1000;
        }
        return inventoryExtracts;
    }

    private Categories getCategoryFromAhspTagsFile(String hwid) throws IOException {
        var data = getDataFromFile(serviceConfiguration.ahspTags);
        var jsonNode = objectMapper.readTree(data);
        var descriptionArray = objectMapper.treeToValue(jsonNode, AhspDescription[].class);
        if (descriptionArray.length == 0) return null;
        var descriptionList = Arrays.asList(descriptionArray);
        var description = descriptionList.stream().filter(desc -> hwid.equalsIgnoreCase(desc.getAshp()))
                .findFirst().orElse(null);
        if (description != null) {
            Categories categories = new Categories();
            Descriptions descriptions = new Descriptions(description.getDescription());
            categories.setEnUs(new ArrayList<>(List.of(descriptions)));
            return categories;
        }
        return null;
    }

    @Override
    public String getHealthWiseArticleVideoJsonData(String accessToken, String apiUrl) throws IOException {
        String bearerToken = accessToken;
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty(AUTHORIZATION, BEARER + bearerToken);
            connection.setRequestProperty("X-HW-Version", "2");
            connection.setRequestProperty("Accept", "application/json");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String inputLine;
                    StringBuilder response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    return response.toString();
                }
            } else {
                LOGGER.info("Request failed with response code (without proxy server): " + responseCode);
            }
        } catch (Exception ex) {
            String token = accessToken;
            String proxyHost = serviceConfiguration.proxyHost;
            int proxyPort = serviceConfiguration.proxyPort;
            String proxyUser = getUName();
            String proxyPassword = getUPwd();
            Authenticator.setDefault(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(proxyUser, proxyPassword.toCharArray());
                }
            });
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);
            connection.setRequestProperty(AUTHORIZATION, BEARER + token);
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            } catch (IOException e) {
                String content = e.getMessage() + " " + e.getCause() + " " + e.toString();
                String message = "Error in fetching the contents from healthwise";
                LOGGER.error(message);
            }
            if (reader == null) {
                LOGGER.error("Failed for " + url.getPath() + "\t\t " + url.getHost());
            }
            String line = null;
            StringBuilder response = new StringBuilder();
            while (true) {
                try {
                    if (null == reader) {
                        break;
                    } else {
                        if ((line = reader.readLine()) == null) break;
                    }
                } catch (IOException e) {
                    throw new JsonReadWriteException(e);
                }
                if (null != line) {
                    response.append(line);
                }
            }
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
                throw new ReaderException(e);
            } catch (NullPointerException e) {
                e.printStackTrace();
                String message = "Error in fetching the contents from healthwise..";
                LOGGER.error(message);
            }
            if (connection != null) {
                connection.disconnect();
                if (isConnectionClosed(connection)) {
                    LOGGER.info("Connection closed successfully.");
                } else {
                }
            }
            return response.toString();
        }
        return null;
    }

    @Override
    public String healthWiseAccessTokenGeneration() throws IOException {
        String authUrl = "https://auth.healthwise.net/v1/oauth2/token";
        String clientId = getClientId();
        String clientSecret = getClientSecret();
        String credentials = clientId + ":" + clientSecret;
        String base64Credentials = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
        String postData = "grant_type=client_credentials&scope=*";
        String accessTokenResponse = null;
        try {
            URL url = new URL(authUrl);
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty(AUTHORIZATION, BASIC + base64Credentials);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setDoOutput(true);
            try (DataOutputStream outputStream = new DataOutputStream(connection.getOutputStream())) {
                outputStream.writeBytes(postData);
                outputStream.flush();
            }
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String inputLine;
                    StringBuilder response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    ObjectMapper objectMapper = new ObjectMapper();
                    JsonNode rootNode = objectMapper.readTree(response.toString());
                    AccessTokenResponse access_token = objectMapper.treeToValue(rootNode.get("access_token"), AccessTokenResponse.class);
                    accessTokenResponse = access_token.getAccessToken();
                    return accessTokenResponse;
                }
            }
        } catch (Exception e) {
            String proxyHost = serviceConfiguration.proxyHost;
            int proxyPort = serviceConfiguration.proxyPort;
            String apiEndpoint = "https://auth.healthwise.net/v1/oauth2/token";
            clientId = getClientId();
            clientSecret = getClientSecret();
            credentials = clientId + ":" + clientSecret;
            base64Credentials = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
            String clientBasic = BASIC + base64Credentials;
            String proxyUsername = getUName();
            String proxyPassword = getUPwd();
            HttpHost proxy = new HttpHost(proxyHost, proxyPort);
            RequestConfig config = RequestConfig.custom().setProxy(proxy).build();
            CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
            credentialsProvider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials(proxyUsername, proxyPassword));
            try (CloseableHttpClient httpClient = HttpClients.custom().setDefaultCredentialsProvider(credentialsProvider).setDefaultRequestConfig(config).build()) {
                HttpPost httpPost = new HttpPost(apiEndpoint);
                httpPost.setHeader(AUTHORIZATION, clientBasic);
                httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded");
                List<BasicNameValuePair> params = new ArrayList<>();
                params.add(new BasicNameValuePair("grant_type", "client_credentials"));
                params.add(new BasicNameValuePair("scope", "*"));
                httpPost.setEntity(new UrlEncodedFormEntity(params));
                HttpResponse response = httpClient.execute(httpPost);
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    HttpEntity entity = response.getEntity();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(entity.getContent()))) {
                        StringBuilder responseBuilder = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            responseBuilder.append(line);
                        }
                        accessTokenResponse = responseBuilder.toString();
                        ObjectMapper objectMapper = new ObjectMapper();
                        JsonNode rootNode = objectMapper.readTree(accessTokenResponse);
                        AccessTokenResponse access_token = objectMapper.treeToValue(rootNode.get("access_token"), AccessTokenResponse.class);
                        accessTokenResponse = access_token.getAccessToken();
                        return accessTokenResponse;
                    }
                } else {
                    LOGGER.info("Failed to obtain access token. Status code: " + statusCode + CURRENTLY_IN_PROXY_SERVER_BASED_ENV);
                }
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public String getUName() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserName);
    }

    @Override
    public String getUPwd() {
        return credentialsManager.decrypt(serviceConfiguration.proxyUserPassword);
    }

    @Override
    public String getClientId() {
        return credentialsManager.decrypt(serviceConfiguration.healthwiseClientId);
    }

    @Override
    public String getClientSecret() {
        return credentialsManager.decrypt(serviceConfiguration.healthwiseClientSecret);
    }

    private static boolean isConnectionClosed(HttpURLConnection connection) {
        try {
            connection.getInputStream();
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    @Override
    public ServiceResponse<HealthWiseDto> getAudioContent(String id, String lang, JsonNode audioJsonData) {
        try {
            if (id.isEmpty() || !(EN_US.equalsIgnoreCase(lang) || ES_US.equalsIgnoreCase(lang)))
                throw new RuntimeException("Invalid ID or Language");
            var healthWiseTopic = new HealthWiseTopic();
            var rootNode = audioJsonData == null ? getAudioJsonData() : audioJsonData;
            var scriptId = lang.equalsIgnoreCase(ES_US) ? id + "_ES" : id;

            healthWiseTopic.setEnglishTopics(objectMapper.treeToValue(rootNode.get("English Topics"), Categories[].class));
            if (ES_US.equalsIgnoreCase(lang)) {
                healthWiseTopic.setSpanishTopics(objectMapper.treeToValue(rootNode.get("Spanish Topics"), Categories[].class));
            }
            var topicsList = EN_US.equalsIgnoreCase(lang) ? healthWiseTopic.getEnglishTopics() : healthWiseTopic.getSpanishTopics();
            var topicData = Arrays.stream(topicsList)
                    .filter(topic -> scriptId.equalsIgnoreCase(topic.getScript()))
                    .findFirst()
                    .orElseThrow(() -> new HealthWiseException("There is no healthWise audio content for the id :" + id + " or for the language : " + lang));
            if (ES_US.equalsIgnoreCase(lang)) {
                topicData.setScriptName(removeExtraCharsForScriptName(topicData.getScriptName()));
            }

            healthWiseTopic.setLengthPerEnglishScripts(objectMapper.treeToValue(rootNode.get("lengthPerEnglishScript"), LengthPerEnglishScript[].class));
            healthWiseTopic.setEnglishCategories(Arrays.stream(objectMapper.treeToValue(rootNode.get("englishCategories"), Categories[].class))
                    .collect(Collectors.toSet()).toArray(Categories[]::new));
            if (ES_US.equalsIgnoreCase(lang)) {
                healthWiseTopic.setSpanishCategories(Arrays.stream(objectMapper.treeToValue(rootNode.get("spanishCategories"), Categories[].class))
                        .collect(Collectors.toSet()).toArray(Categories[]::new));
            }

            var categoriesList = EN_US.equalsIgnoreCase(lang) ? healthWiseTopic.getEnglishCategories() : healthWiseTopic.getSpanishCategories();
            var category = Arrays.stream(categoriesList)
                    .filter(topic -> topic.getScript().equalsIgnoreCase(scriptId))
                    .findFirst().orElseThrow(() -> new HealthWiseException("No tags are present for the healthWise audio id : " + id));

            if (lang.equalsIgnoreCase(ES_US)) {
                category.setScript(category.getScript().replace("_ES", ""));
            }

            var response = getHealthWiseResponseData(id, lang, healthWiseTopic, category);
            response.setContentId(id);
            response.setTitle(topicData.getScriptName());
            response.setDescription(topicData.getScriptName());
            response.setTags(getAudioTags(id, healthWiseTopic.getEnglishCategories()));
            return new ServiceResponse<HealthWiseDto>().success(response);
        } catch (Exception e) {
            return new ServiceResponse<HealthWiseDto>().error(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    private JsonNode getAudioJsonData() throws IOException {
        var audioJsonData = getDataFromFile(serviceConfiguration.audioTitleFile);
        var rootNode = objectMapper.readTree(audioJsonData);
        return rootNode;
    }

    private String removeExtraCharsForScriptName(String scriptName) {
        var lastIndex = scriptName.contains("- [") ? scriptName.indexOf("- [") : -1;
        lastIndex = lastIndex == -1 ? (scriptName.contains("[") ? scriptName.indexOf("[") : -1) : lastIndex;
        return scriptName.substring(0, lastIndex == -1 ? scriptName.length() : lastIndex).trim();
    }

    private HealthWiseDto getHealthWiseResponseData(String id, String lang, HealthWiseTopic healthWiseTopic, Categories category) throws HealthWiseException {
        var response = new HealthWiseDto();
        response.setContentType(AUDIO);
        response.setLanguage(lang);
        response.setSource("HealthWise");
        response.setSourceVersion(BigDecimal.valueOf(2.9));
        response.setCreatedTime(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        response.setModifiedTime(response.getCreatedTime());
        response.setImage(getRandomImageUrl());
        var transcript = getPdfData(id, lang);
        if (transcript == null) {
            throw new HealthWiseException("There is no transcript available for the healthWise id : " + id);
        }
        response.setTranscript(transcript);
        response.setAudioType("upload");
        var length = Arrays.stream(healthWiseTopic.getLengthPerEnglishScripts())
                .filter(script -> script.getScript().equalsIgnoreCase(id))
                .findFirst().orElse(new LengthPerEnglishScript()).getLength();
        Integer audioDuration = null;
        if (length != null) {
            audioDuration = convertMinutesToSeconds(length);
        }
        response.setAudioDuration(audioDuration);
        response.setAudioUrl(checkAndGetMp3Url(id, lang));
        response.setCredits(lang.equalsIgnoreCase(EN_US) ? "Healthwise Staff" : "El personal de Healthwise");
        response.setDisclaimer(lang.equalsIgnoreCase(EN_US) ? EN_AUDIO_DISCLAIMER : ES_AUDIO_DISCLAIMER);
        return response;
    }

    private List<String> getAudioTags(String id, Categories[] categoriesList) throws HealthWiseException {
        var listOfCatergories = Arrays.stream(categoriesList)
                .filter(topic -> topic.getScript().equalsIgnoreCase(id))
                .collect(Collectors.toList());
        var tags = new ArrayList<String>();
        for (var cat : listOfCatergories) {
            var exploreCategory = exploreCategoryRepo.findByCodeIgnoreCase(capitalize(cat.getCategoryName()));
            if (exploreCategory == null) {
                LOGGER.error("There is no " + cat.getCategoryName() + " present in explore category db table.");
                continue;
            }
            tags.add("ahm:MAH Tags/Topic/" + exploreCategory.getExploreTopicId().getCode() + "/" + convertToUpperCase(exploreCategory.getDescription()));
        }
        if (tags.isEmpty()) {
            throw new HealthWiseException("No tags are present for the healthWise audio id : " + id);
        }
        tags.addAll(List.of("ahm:MAH Tags/Gender/Male", "ahm:MAH Tags/Gender/Female", "ahm:MAH Tags/Age/Childhood", "ahm:MAH Tags/Age/Teen", "ahm:MAH Tags/Age/Adult", "ahm:MAH Tags/Age/Senior", "ahm:MAH Tags/Content Type/Audio"));
        return tags;
    }

    private String convertToUpperCase(String value){
        String[] words= value.split(" ");
        StringBuilder name = new StringBuilder();
        for (String word:words) {
            name.append(word.substring(0,1).toUpperCase()+ word.substring(1)).append(" ");
        }
        return name.toString().trim();
    }

    private Integer convertMinutesToSeconds(String duration) {
        var lengthArray = duration.split(":");
        var hours = (lengthArray.length > 0 ? Integer.valueOf(lengthArray[0]) : 0) * 3600;
        var minutes = (lengthArray.length > 1 ? Integer.valueOf(lengthArray[1]) : 0) * 60;
        var seconds = lengthArray.length > 2 ? Integer.valueOf(lengthArray[2]) : 0;
        return hours + minutes + seconds;
    }

    private String capitalize(String str) {
        return Arrays.stream(str.split(" "))
                .map(word -> word.substring(0, 1).toUpperCase() + word.substring(1))
                .collect(Collectors.joining(" "));
    }

    public String getDataFromFile(String url) throws IOException {
        String data = null;
        if (url.isEmpty()) {
            return data;
        }
        data = resourceToString(url, Charset.defaultCharset(), this.getClass().getClassLoader());
        return StringUtils.hasLength(data) ? data : null;
    }

    private String getPdfData(String id, String lang) {
        String id1 = StringEscapeUtils.escapeHtml4(id);
        String lang1 = StringEscapeUtils.escapeHtml4(lang);
        String url = lang1.equalsIgnoreCase(EN_US)
                ? serviceConfiguration.transcriptPathEn
                : serviceConfiguration.transcriptPathEs;
        String fileName = "";
        Whitelist whitelist = null;
        Cleaner cleaner = null;
        Document cleanDocument = null;

        try {
            StringBuilder data = new StringBuilder();
            String htmlData = "";
            try (Stream<Path> paths = Files.list(Paths.get(getClass().getResource(url).toURI()))) {
                List<String> filesList = paths.filter(Files::isRegularFile).map(Path::getFileName).map(Path::toString).toList();
                fileName = filesList.stream().filter(name -> name.contains(id1)).findFirst().get();
                url = url + "/" + fileName;
                ClassPathResource classPathResource = new ClassPathResource(url);
                InputStream inputStream = classPathResource.getInputStream();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        data.append(line).append(" ");
                    }
                }
                htmlData = data.toString();
                Document pageHtmlDocument = Jsoup.parse(htmlData);
                whitelist = Whitelist.basic();
                cleaner = new Cleaner(whitelist);
                cleanDocument = cleaner.clean(pageHtmlDocument);
                htmlData = cleanDocument.html();
            }
            return htmlData.length() == 0 ? null : htmlData;
        } catch (Exception e) {
            return null;
        }
    }

    private String checkAndGetMp3Url(String id, String lang) {
        return lang.equalsIgnoreCase("en-us")
                ? serviceConfiguration.baseUrlForMp3 + "en/" + id.substring(0, 1) + "/" + id + ".mp3"
                : serviceConfiguration.baseUrlForMp3 + "es/" + id.substring(0, 1) + "/" + id.replace("_ES", "") + ".mp3";
    }

    private String getRandomImageUrl() {
        var images = exploreImageRepo.findAll();
        return serviceConfiguration.baseUrlForImage + images.get(new Random().nextInt(0, images.size())).getImageUrl();
    }

    public HealthWiseDto sanitizeHealthWiseData(HealthWiseDto healthWiseDto) {
        healthWiseDto.setDisclaimer(Objects.nonNull(healthWiseDto.getDisclaimer()) ? sanitizeContent(healthWiseDto.getDisclaimer()) : null);
        healthWiseDto.setTranscript(Objects.nonNull(healthWiseDto.getTranscript()) ? sanitizeContent(healthWiseDto.getTranscript()) : null);
        healthWiseDto.setCredits(Objects.nonNull(healthWiseDto.getCredits()) ? sanitizeContent(healthWiseDto.getCredits()) : null);
        return healthWiseDto;
    }

    private String sanitizeContent(String content) {
        Document pageHtmlDocument = Jsoup.parse(content);
        Whitelist whitelist = Whitelist.basic();
        Cleaner cleaner = new Cleaner(whitelist);
        Document cleanDocument = cleaner.clean(pageHtmlDocument);
        return cleanDocument.html();
    }

}





