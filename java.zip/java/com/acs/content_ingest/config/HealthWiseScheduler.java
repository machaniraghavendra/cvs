package com.acs.content_ingest.config;

import com.acs.content_ingest.dto.InventoryExtract;
import com.acs.content_ingest.entities.AcsIngredientGroups;
import com.acs.content_ingest.entities.AcsIngredients;
import com.acs.content_ingest.entities.AcsParent;
import com.acs.content_ingest.exceptions.HealthWiseException;
import com.acs.content_ingest.impl.HealthWiseContentIngestServiceImpl;
import com.acs.content_ingest.impl.MeredithArticleToDbServiceImpl;
import com.acs.content_ingest.impl.MeredithRecipeToDbServiceImpl;
import com.acs.content_ingest.interfaces.ContentToAcsService;
import com.acs.content_ingest.interfaces.HealthWiseDataToDb;
import com.acs.content_ingest.interfaces.MeredithRecipeToAcsService;
import com.acs.content_ingest.repository.AcsParentRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.acs.content_ingest.constents.ApplicationMessage.*;


@Component
@EnableScheduling
public class HealthWiseScheduler {

    private static final Logger logger = LoggerFactory.getLogger(HealthWiseScheduler.class);

    @Autowired
    private AcsParentRepo acsParentRepo;

    @Autowired
    HealthWiseContentIngestServiceImpl healthWiseContentIngestService;

    @Value("${healthWise-scheduler.cron}")
    public String healthWiseCron;

    @Autowired
    HealthWiseDataToDb healthWiseDataToDb;

    @Autowired
    ContentToAcsService contentToAcsService;

    @Autowired
    MeredithRecipeToDbServiceImpl meredithRecipeToDbService;

    @Autowired
    MeredithArticleToDbServiceImpl meredithArticleToDbService;

    @Autowired
    MeredithRecipeToAcsService meredithRecipeToAcsService;

    @Scheduled(cron = "#{@healthWiseScheduler.healthWiseCron}")
    public void heathWiseScheduler() {
        CompletableFuture.runAsync(() -> {
            runScheduler(ARTICLE);
            runScheduler(VIDEO);
            runSchedulerForRecipe();
            runSchedulerForTips();
        });
    }

    private void runSchedulerForTips() {
        try {
            //DB call
            Optional<List<AcsParent>> acParentResponseForMeredithArticle = acsParentRepo.getAllMeredithArticles("article");
            Map<String, String> allMeredithArticlesWithModifiedTime = acParentResponseForMeredithArticle.get().stream().
                    collect(Collectors.toMap(AcsParent::getContentId, AcsParent::getModifiedTime));
            Map<String, AcsParent> acsParentWIthContentId = acParentResponseForMeredithArticle.get().stream()
                    .collect(Collectors.toMap(AcsParent::getContentId, Function.identity()));
            //API call
            var meredithArticleJsonNodes = meredithArticleToDbService.getMeredithArticleDetailJsonNodes("ASC", "id", 0, EN_US);
            if (!meredithArticleJsonNodes.getIsSuccess()) {
                throw new HealthWiseException("Data not found for meredith articles");
            }
            var meredithArticleIds = meredithArticleJsonNodes.getResult();
            Map<String, String> allArticlesWithModifiedTimeFromMeredith = meredithArticleIds.stream()
                    .collect(Collectors.toMap(a -> a.get("id").asText(),
                            a -> a.get("updatedAt").asText().substring(0, a.get("updatedAt").asText().indexOf("T"))));
            List<String> idsForUpdate = new ArrayList<>();
            allMeredithArticlesWithModifiedTime.entrySet().forEach(entry -> {
                var modifiedDate = allArticlesWithModifiedTimeFromMeredith.get(entry.getKey());
                if (modifiedDate != null) {
                    if (modifiedDate.equalsIgnoreCase(entry.getValue())) {
                        allArticlesWithModifiedTimeFromMeredith.remove(entry.getKey());
                    } else {
                        idsForUpdate.add(entry.getKey());
                    }
                }
            });
            var idsForPost = allArticlesWithModifiedTimeFromMeredith.keySet();

            if (!idsForUpdate.isEmpty() || !idsForPost.isEmpty()) {
                //Update existing record
                updateAcsParentMeredithArticle(idsForUpdate, acsParentWIthContentId);

                //insert into db
                idsForPost.forEach(a -> meredithArticleToDbService.saveMeredithArticleDataToDb(a, EN_US));

                // PutToAcs
                idsForUpdate.forEach(contentId -> contentToAcsService.postAndUpdateContentToAcsContentFragments(contentId, ARTICLE, null, Boolean.TRUE));

                //PostToAcs
                idsForPost.forEach(contentId -> contentToAcsService.postAndUpdateContentToAcsContentFragments(contentId, ARTICLE, null, Boolean.FALSE));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void runSchedulerForRecipe() {
        try {
            //DB call
            Optional<List<AcsParent>> acParentResponseForRecipe = acsParentRepo.getContentIdWithContentTypeForRecipes("recipe");
            Map<String, String> allTheRecipesWithModifiedTime = acParentResponseForRecipe.get().stream().
                    collect(Collectors.toMap(AcsParent::getContentId, AcsParent::getModifiedTime));
            Map<String, AcsParent> acsParentWIthContentId = acParentResponseForRecipe.get().stream()
                    .collect(Collectors.toMap(AcsParent::getContentId, Function.identity()));
            //API call
            var meredithRecipesJsonNodes = meredithRecipeToDbService.getAllMeredithRecipes("ASC", "id", 0, EN_US, null);
            if (!meredithRecipesJsonNodes.getIsSuccess()) {
                throw new HealthWiseException("Data not found for recipes");
            }
            var recipeResult = meredithRecipesJsonNodes.getResult();
            Map<String, String> allTheRecipesWithModifiedTimeFromMeredith = recipeResult.stream()
                    .collect(Collectors.toMap(a -> a.get("id").asText(),
                            a -> a.get("updatedAt").asText().substring(0, a.get("updatedAt").asText().indexOf("T"))));
            List<String> idsForUpdate = new ArrayList<>();
            allTheRecipesWithModifiedTime.entrySet().forEach(entry -> {
                var modifiedDate = allTheRecipesWithModifiedTimeFromMeredith.get(entry.getKey());
                if (modifiedDate != null) {
                    if (modifiedDate.equalsIgnoreCase(entry.getValue())) {
                        allTheRecipesWithModifiedTimeFromMeredith.remove(entry.getKey());
                    } else {
                        idsForUpdate.add(entry.getKey());
                    }
                }
            });
            var idsForPost = allTheRecipesWithModifiedTimeFromMeredith.keySet();

            if (!idsForUpdate.isEmpty() || !idsForPost.isEmpty()) {
                //Update existing record
                updateAcsParent(idsForUpdate, acsParentWIthContentId);

                //insert into db
                idsForPost.forEach(a -> meredithRecipeToDbService.saveMeredithRecipeDataToDb(a, EN_US));

                // PutToAcs
                idsForUpdate.forEach(contentId -> meredithRecipeToAcsService.postRecipeContentToAcsContentFragment(contentId, "recipe", null, Boolean.TRUE));

                //PostToAcs
                idsForPost.forEach(contentId -> meredithRecipeToAcsService.postRecipeContentToAcsContentFragment(contentId, "recipe", null, Boolean.FALSE));
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void updateAcsParentMeredithArticle(List<String> idsForUpdate, Map<String, AcsParent> acsParentWIthContentId) throws HealthWiseException {
        for (var contentId : idsForUpdate) {
            var healthWiseDtoWithLatestData = meredithRecipeToDbService.getMeredithRecipeData(contentId, EN_US, null);
            var acsParentWithUpdatedData = healthWiseDataToDb.convertHealthWiseDtoToAcsParent(healthWiseDtoWithLatestData.getResult());
            var acsParent = acsParentWIthContentId.get(contentId);
            acsParentWithUpdatedData.setStatus(Boolean.FALSE);
            acsParentWithUpdatedData.setId(acsParent.getId());

            acsParentWithUpdatedData.getArticleContentId().setId(acsParent.getArticleContentId().getId());
            acsParentWithUpdatedData.getArticleContentId().setStatus(Boolean.FALSE);

            acsParentWithUpdatedData.getCopyRightContentId().setId(acsParent.getCopyRightContentId().getId());
            acsParentWithUpdatedData.getCopyRightContentId().setStatus(Boolean.FALSE);

            acsParentRepo.save(acsParentWithUpdatedData);
        }
    }


    private void updateAcsParent(List<String> idsForUpdate, Map<String, AcsParent> acsParentWIthContentId) throws HealthWiseException {
        for (var contentId : idsForUpdate) {
            var healthWiseDtoWithLatestData = meredithRecipeToDbService.getMeredithRecipeData(contentId, EN_US, null);
            var acsParentWithUpdatedData = healthWiseDataToDb.convertHealthWiseDtoToAcsParent(healthWiseDtoWithLatestData.getResult());
            var acsParent = acsParentWIthContentId.get(contentId);
            acsParentWithUpdatedData.setStatus(Boolean.FALSE);
            acsParentWithUpdatedData.setId(acsParent.getId());

            acsParentWithUpdatedData.getCopyRightContentId().setId(acsParent.getCopyRightContentId().getId());
            acsParentWithUpdatedData.getCopyRightContentId().setStatus(Boolean.FALSE);

            acsParentWithUpdatedData.getRecipeContentId().setId(acsParent.getRecipeContentId().getId());
            acsParentWithUpdatedData.getRecipeContentId().setStatus(Boolean.FALSE);


            var mapOfIngredientGroups = acsParent.getRecipeContentId().getAcsIngredientGroups().stream()
                    .collect(Collectors.toMap(AcsIngredientGroups::getName, Function.identity()));

            acsParentWithUpdatedData.getRecipeContentId().getAcsIngredientGroups().forEach(group -> {
                group.setId(mapOfIngredientGroups.get(group.getName()).getId());
                group.setStatus(Boolean.FALSE);
                var mapOfIngredients = mapOfIngredientGroups.get(group.getName()).getAcsIngredients()
                        .stream().collect(Collectors.toMap(AcsIngredients::getOrdinal, Function.identity()));
                group.getAcsIngredients().forEach(acsIngredient -> {
                    acsIngredient.setId(mapOfIngredients.get(acsIngredient.getOrdinal()).getId());
                    acsIngredient.setStatus(Boolean.FALSE);
                });
            });

            acsParentRepo.save(acsParentWithUpdatedData);
        }
    }

    private void runScheduler(String contentType) {
        try {
            var currentDate = new Date(System.currentTimeMillis());
            logger.info("Scheduler started for the date of {}", currentDate);
            var acsParentResponse = acsParentRepo.getFirstContentIdWithContentType(contentType);
            if (acsParentResponse.isPresent()) {
                var acsParent = acsParentResponse.get();
                //Get data from healthWise api
                var healthWiseJsonData = healthWiseContentIngestService.getHealthWiseArticleVideoJsonDataByIdAndLang(acsParent.getContentId(), EN_US);
                if (healthWiseJsonData != null && !healthWiseJsonData.isEmpty()) {
                    var rootNode = new ObjectMapper().readTree(healthWiseJsonData);
                    var rootNodeData = rootNode.get("data");
                    var version = BigDecimal.valueOf(rootNodeData.get("version").asDouble());
                    if (acsParent.getSourceVersion().compareTo(version) == 0) {
                        logger.info("New content not found for the {} on the date of : {}", contentType, currentDate);
                    } else {
                        initiatingSchedulerWithNewVersion(contentType, currentDate, acsParent);
                    }
                } else {
                    logger.info("New content found for the {} on the date of : {}", contentType, currentDate);
                    try {
                        initiatingSchedulerWithNewVersion(contentType, currentDate, acsParent);
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                    }
                }
            } else {
                logger.info("No data found for the {}", contentType);
            }
            logger.info("Completed the scheduler job in {} minutes", (new Date(System.currentTimeMillis()).getTime() - currentDate.getTime()) / (60 * 1000));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void initiatingSchedulerWithNewVersion(String contentType, Date currentDate, AcsParent acsParent) {
        logger.info("New content found for the {} on the date of : {}", contentType, currentDate);
        try {
            var inventoryData = healthWiseContentIngestService.getInventoryDataBasedOnContentType(null, Boolean.TRUE, contentType);
            //Get data from inventory api
            if (inventoryData.isEmpty()) {
                throw new HealthWiseException("Failed to fetch inventory data for " + contentType);
            }
            var response = processArticleAndVideoScheduler(acsParent.getSourceVersion(), EN_US, contentType, inventoryData);
            processArticleAndVideoScheduler(acsParent.getSourceVersion(), ES_US, contentType, inventoryData);
            putAndPostOperationIntoAcs(contentType, response.get("UPDATE"), response.get("INSERT"), inventoryData.get(0).getVersion());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private Map<String, List<String>> processArticleAndVideoScheduler(BigDecimal oldVersion, String lang, String contentType, List<InventoryExtract> inventoryData) throws HealthWiseException {
        Map<String, List<String>> listOfIdsData = new HashMap<>();
        var contentInventoryDataIds = inventoryData.stream().map(InventoryExtract::getHwid).toList();
        //Get the ids from db
        var postedArticles = acsParentRepo.getAllIdsWithStatusFlagTrue(contentType, lang, oldVersion);
        if (postedArticles.isEmpty() || postedArticles.get().isEmpty()) {
            throw new HealthWiseException("Failed to fetch data for " + contentType + " from db");
        }
        var mapOfContentIdAndAcsParent = postedArticles.get().stream()
                .collect(Collectors.toMap(AcsParent::getContentId, Function.identity()));

        var listOfAcsParentForUpdate = new ArrayList<AcsParent>();
        var listOfIdsForPost = new ArrayList<String>();

        compareAndAddToUpdateAndPostLists(contentInventoryDataIds, mapOfContentIdAndAcsParent.keySet().stream().toList(),
                listOfIdsForPost, listOfAcsParentForUpdate, mapOfContentIdAndAcsParent);

        insertAndUpdateInDbAndAcs(lang, contentType, listOfAcsParentForUpdate, listOfIdsForPost, inventoryData);
        listOfIdsData.put("INSERT", listOfIdsForPost);
        listOfIdsData.put("UPDATE", listOfAcsParentForUpdate.stream().map(AcsParent::getContentId).toList());
        return listOfIdsData;
    }

    private void insertAndUpdateInDbAndAcs(String lang, String contentType, List<AcsParent> listOfAcsParentForUpdate,
                                           List<String> listOfIdsForPost, List<InventoryExtract> inventoryExtracts) throws HealthWiseException {
        //Persist the data to db
        //Process the acsParent for update
        logger.info("Starting the process of updating the acsParents for {} for version : {}", contentType, listOfAcsParentForUpdate.get(0).getSourceVersion());
        updateDbRecordsWithNewVersionFromInventory(lang, listOfAcsParentForUpdate, inventoryExtracts);
        logger.info("Completed the process of updating the acsParents for {}", contentType);

        //Process the acsParent for post
        logger.info("Starting the process of inserting the new acsParents for {} for version : {}", contentType, listOfAcsParentForUpdate.get(0).getSourceVersion());
        listOfIdsForPost.forEach(contentId -> healthWiseContentIngestService.saveHealthWiseData(contentId, lang));
        logger.info("Completed the process of inserting the new acsParents for {}", contentType);
    }

    private void putAndPostOperationIntoAcs(String contentType, List<String> listOfContentIdForUpdate, List<String> listOfContentIdsForPost, String version) {
        //Ingest the data to acs
        //Process to update the fragment to acs
        logger.info("Starting the process of updating the data to ACS for {} for new version : {}", contentType, version);
        listOfContentIdForUpdate.forEach(contentId -> contentToAcsService.postAndUpdateContentToAcsContentFragments(contentId, contentType, null, Boolean.TRUE));
        logger.info("Completed the process of updating the acsParents for {}", contentType);

        //Process to post the fragment to acs
        logger.info("Starting the process of inserting the new acsParents to ACS for {} for new version : {}", contentType, version);
        listOfContentIdsForPost.forEach(contentId -> contentToAcsService.postAndUpdateContentToAcsContentFragments(contentId, contentType, null, Boolean.FALSE));
        logger.info("Completed the process of inserting the acsParents to ACS for {}", contentType);
    }

    private void updateDbRecordsWithNewVersionFromInventory(String lang, List<AcsParent> listOfAcsParentForUpdate, List<InventoryExtract> inventoryExtracts) throws HealthWiseException {
        for (var acsParent : listOfAcsParentForUpdate) {
            var healthWiseDtoWithLatestData = healthWiseContentIngestService.getHealthWiseArticleVideoData(acsParent.getContentId(), lang, inventoryExtracts);
            if (!healthWiseDtoWithLatestData.getIsSuccess()) {
                logger.error("Exception while fetching and mapping to HealthWise dto for id : " + acsParent.getContentId());
                continue;
            }
            var acsParentWithUpdatedData = healthWiseDataToDb.convertHealthWiseDtoToAcsParent(healthWiseDtoWithLatestData.getResult());
            acsParentWithUpdatedData.setId(acsParent.getId());
            acsParentWithUpdatedData.setStatus(Boolean.FALSE);

            acsParentWithUpdatedData.getArticleContentId().setId(acsParent.getArticleContentId().getId());
            acsParentWithUpdatedData.getArticleContentId().setStatus(Boolean.FALSE);

            acsParentWithUpdatedData.getCopyRightContentId().setId(acsParent.getCopyRightContentId().getId());
            acsParentWithUpdatedData.getCopyRightContentId().setStatus(Boolean.FALSE);

            acsParentRepo.save(acsParentWithUpdatedData);
        }
    }

    private void compareAndAddToUpdateAndPostLists(List<String> contentInventoryDataIds, List<String> contentPostedIds,
                                                   List<String> listOfIdsForPost, List<AcsParent> listOfAcsParentForUpdate,
                                                   Map<String, AcsParent> mapOfContentIdAndAcsParent) {
        var mapOfUpdateAndPostingIds = contentInventoryDataIds.stream()
                .collect(Collectors.partitioningBy(contentPostedIds::contains));
        listOfIdsForPost.addAll(mapOfUpdateAndPostingIds.get(Boolean.FALSE));
        var lisOfIdsForUpdate = mapOfUpdateAndPostingIds.get(Boolean.TRUE);
        listOfAcsParentForUpdate.addAll(mapOfContentIdAndAcsParent.entrySet().stream()
                .filter(a -> lisOfIdsForUpdate.contains(a.getKey())).map(Map.Entry::getValue).toList());
    }
}
