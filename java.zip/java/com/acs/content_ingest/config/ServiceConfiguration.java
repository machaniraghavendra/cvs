package com.acs.content_ingest.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties
public class ServiceConfiguration {

    @Value("${proxy.host}")
    public String proxyHost;

    @Value("${proxy.port}")
    public Integer proxyPort;

    @Value("${proxy.user-name}")
    public String proxyUserName;

    @Value("${proxy.user-password}")
    public String proxyUserPassword;

    @Value("${proxy.public-key}")
    public String proxyPublicKey;

    @Value("${proxy.private-key}")
    public String proxyPrivateKey;

    @Value("${healthwise.client-id}")
    public String healthwiseClientId;

    @Value("${healthwise.client-secret}")
    public String healthwiseClientSecret;

    @Value("${healthwise.article-video-url}")
    public String healthwiseUrl;

    @Value("${healthwise.inventory-url}")
    public String healthwiseInventoryUrl;

    @Value("${healthwise.audioTitleFile}")
    public String audioTitleFile;

    @Value("${healthwise.mp3SourcePathEn}")
    public String mp3SourcePathEn;

    @Value("${healthwise.mp3SourcePathEs}")
    public String mp3SourcePathEs;

    @Value("${healthwise.baseUrlForMp3}")
    public String baseUrlForMp3;

    @Value("${healthwise.transcriptPathEn}")
    public String transcriptPathEn;

    @Value("${healthwise.transcriptPathEs}")
    public String transcriptPathEs;

    @Value("${healthwise.baseUrlForImage}")
    public String baseUrlForImage;

    @Value("${acs.orgId}")
    public String acsOrgId;

    @Value("${acs.techAccountId}")
    public String acsTechAccountId;

    @Value("${acs.clientId}")
    public String acsClientId;

    @Value("${acs.clientSecret}")
    public String acsClientSecret;

    @Value("${acs.privateKeyPath}")
    public String acsPrivateKeyPath;

    @Value("${meredith.meredithArticle}")
    public String meredithArticleUrl;

    @Value("${meredith.tips_strategies_spanish_content}")
    public String spanishMeredithContent;

    @Value("${meredith.apiKey}")
    public String apiKey;

    @Value("${meredith.tags-tips-strategies}")
    public String tagsTips;

    @Value("${meredith.meredithRecipe}")
    public String meredithRecipeUrl;

    @Value("${meredith.spanishRecipeUrl}")
    public String spanishRecipeUrl;

    @Value("${healthWise-scheduler.cron}")
    public String healthWiseCron;

    @Value("${healthwise.ahsp-tags}")
    public String ahspTags;


}
